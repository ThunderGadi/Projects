#ifndef DESPACHO_H
#define DESPACHO_H

#include <string>

using namespace std;

class Solicitud;
class Paquete;
class Cliente;
class Colaborador;
class CentroDistribucion;

class Despacho {
private:
    string codigo;
    Solicitud* solicitud;
    Paquete* paquete;
    Cliente* cliente;
    Colaborador* colaborador;
    CentroDistribucion* centroOrigen;
    string destino;
    string fecha;
    string hora;
    string estado;

public:
    static const string EN_PROCESO;
    static const string FINALIZADO;

    Despacho(string codigo, Solicitud* solicitud, string fecha, string hora);

    string getCodigo();
    Solicitud* getSolicitud();
    Paquete* getPaquete();
    Cliente* getCliente();
    Colaborador* getColaborador();
    CentroDistribucion* getCentroOrigen();
    string getDestino();
    string getFecha();
    string getHora();
    string getEstado();

    bool puedeFinalizar();
    bool finalizar(const string& fechaEntrega);

    void mostrarDatos();
    void mostrarResumen();
};

#endif
