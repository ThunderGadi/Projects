#include "Paquete.h"
#include "Bodega.h"
#include "Cliente.h"
#include "Colaborador.h"
#include "CentroDistribucion.h"
#include "Despacho.h"
#include "RegistroEstado.h"
#include "Categoria.h"

#include <iostream>

using namespace std;

const string Paquete::RECIBIDO = "Recibido";
const string Paquete::ALMACENADO = "Almacenado";
const string Paquete::EN_TRANSITO = "En transito";
const string Paquete::ENTREGADO = "Entregado";
const string Paquete::INCIDENCIA = "Incidencia";

Paquete::Paquete(string codigoUnico, string descripcion, double peso, int categoria,
    Cliente* cliente, CentroDistribucion* centro) {
    this->codigoUnico = codigoUnico;
    this->descripcion = descripcion;
    this->peso = peso;
    this->categoria = categoria;
    this->cliente = cliente;
    this->centro = centro;
    estadoActual = RECIBIDO;
    bodega = nullptr;
    fila = -1;
    columna = -1;
    despacho = nullptr;
}

Paquete::~Paquete() {
    while (!bitacora.vacia()) {
        delete bitacora.extraerPrimero();
    }
}

string Paquete::getCodigoUnico() {
    return codigoUnico;
}

string Paquete::getDescripcion() {
    return descripcion;
}

double Paquete::getPeso() {
    return peso;
}

int Paquete::getCategoria() {
    return categoria;
}

string Paquete::getNombreCategoria() {
    return Categoria::nombre(categoria);
}

Cliente* Paquete::getCliente() {
    return cliente;
}

CentroDistribucion* Paquete::getCentro() {
    return centro;
}

string Paquete::getEstadoActual() {
    return estadoActual;
}

Bodega* Paquete::getBodega() {
    return bodega;
}

int Paquete::getFila() {
    return fila;
}

int Paquete::getColumna() {
    return columna;
}

Despacho* Paquete::getDespacho() {
    return despacho;
}

bool Paquete::tieneUbicacion() {
    return bodega != nullptr;
}

string Paquete::getUbicacion() {
    if (bodega == nullptr) return "Sin asignar";
    return bodega->nombreCelda(fila, columna);
}

bool Paquete::tieneDespachoEnProceso() {
    return despacho != nullptr && despacho->getEstado() == Despacho::EN_PROCESO;
}

bool Paquete::requiereAlmacenamiento() {
    if (estadoActual == RECIBIDO) return true;
    return estadoActual == INCIDENCIA && bodega == nullptr && despacho == nullptr;
}

Lista<RegistroEstado*>& Paquete::getBitacora() {
    return bitacora;
}

bool Paquete::transicionPermitida(const string& nuevoEstado) {
    if (estadoActual == RECIBIDO) {
        return nuevoEstado == ALMACENADO || nuevoEstado == INCIDENCIA;
    }
    if (estadoActual == ALMACENADO) {
        return nuevoEstado == EN_TRANSITO || nuevoEstado == INCIDENCIA;
    }
    if (estadoActual == EN_TRANSITO) {
        return nuevoEstado == ENTREGADO || nuevoEstado == INCIDENCIA;
    }
    if (estadoActual == INCIDENCIA) {
        return nuevoEstado == ALMACENADO || nuevoEstado == EN_TRANSITO;
    }
    return false;
}

bool Paquete::colaboradorValido(Colaborador* colaborador) {
    return colaborador != nullptr && centro != nullptr && centro->getColaboradores().contiene(colaborador);
}

bool Paquete::cambiarEstado(const string& nuevoEstado, Colaborador* colaborador, const string& fecha) {
    if (!transicionPermitida(nuevoEstado) || !colaboradorValido(colaborador)) {
        return false;
    }
    string anterior = estadoActual;
    estadoActual = nuevoEstado;
    bitacora.agregar(new RegistroEstado(anterior, nuevoEstado, fecha, colaborador));
    return true;
}

void Paquete::liberarUbicacion() {
    if (bodega != nullptr) {
        bodega->liberarCelda(fila, columna);
    }
    bodega = nullptr;
    fila = -1;
    columna = -1;
}

bool Paquete::almacenar(Bodega* nuevaBodega, int nuevaFila, int nuevaColumna, Colaborador* colaborador, const string& fecha) {
    if (!requiereAlmacenamiento() || nuevaBodega == nullptr || !nuevaBodega->esCompatible(categoria)) {
        return false;
    }
    if (!nuevaBodega->estaDisponible(nuevaFila, nuevaColumna) || !colaboradorValido(colaborador)) {
        return false;
    }
    if (!nuevaBodega->asignarPaquete(nuevaFila, nuevaColumna, this)) {
        return false;
    }
    if (!cambiarEstado(ALMACENADO, colaborador, fecha)) {
        nuevaBodega->liberarCelda(nuevaFila, nuevaColumna);
        return false;
    }
    bodega = nuevaBodega;
    fila = nuevaFila;
    columna = nuevaColumna;
    return true;
}

bool Paquete::reubicar(Bodega* nuevaBodega, int nuevaFila, int nuevaColumna) {
    if (estadoActual != ALMACENADO || bodega == nullptr || nuevaBodega == nullptr) {
        return false;
    }
    if (!nuevaBodega->esCompatible(categoria) || !nuevaBodega->estaDisponible(nuevaFila, nuevaColumna)) {
        return false;
    }
    if (!nuevaBodega->asignarPaquete(nuevaFila, nuevaColumna, this)) {
        return false;
    }
    if (!bodega->liberarCelda(fila, columna)) {
        nuevaBodega->liberarCelda(nuevaFila, nuevaColumna);
        return false;
    }
    bodega = nuevaBodega;
    fila = nuevaFila;
    columna = nuevaColumna;
    return true;
}

bool Paquete::registrarIncidencia(Colaborador* colaborador, const string& fecha) {
    if (estadoActual != RECIBIDO && estadoActual != ALMACENADO && estadoActual != EN_TRANSITO) {
        return false;
    }
    return cambiarEstado(INCIDENCIA, colaborador, fecha);
}

bool Paquete::resolverIncidencia(Colaborador* colaborador, const string& fecha) {
    if (estadoActual != INCIDENCIA) return false;
    if (bodega != nullptr) {
        return cambiarEstado(ALMACENADO, colaborador, fecha);
    }
    if (tieneDespachoEnProceso()) {
        return cambiarEstado(EN_TRANSITO, colaborador, fecha);
    }
    return false;
}

bool Paquete::iniciarTransito(Despacho* nuevoDespacho, Colaborador* colaborador, const string& fecha) {
    if (estadoActual != ALMACENADO || despacho != nullptr || nuevoDespacho == nullptr) {
        return false;
    }
    if (!cambiarEstado(EN_TRANSITO, colaborador, fecha)) {
        return false;
    }
    liberarUbicacion();
    despacho = nuevoDespacho;
    return true;
}

bool Paquete::entregar(Colaborador* colaborador, const string& fecha) {
    if (estadoActual != EN_TRANSITO || !tieneDespachoEnProceso()) {
        return false;
    }
    if (!cambiarEstado(ENTREGADO, colaborador, fecha)) {
        return false;
    }
    liberarUbicacion();
    return true;
}

void Paquete::mostrarDatos() {
    cout << "Codigo: " << codigoUnico << endl;
    cout << "Descripcion: " << descripcion << endl;
    cout << "Peso: " << peso << " kg" << endl;
    cout << "Categoria: " << getNombreCategoria() << endl;
    cout << "Cliente propietario: ";
    if (cliente != nullptr) cout << cliente->getNombre() << " (" << cliente->getIdCliente() << ")";
    cout << endl;
    cout << "Centro de distribucion: ";
    if (centro != nullptr) cout << centro->getNombre() << " (" << centro->getCodigoUnico() << ")";
    cout << endl;
    cout << "Estado actual: " << estadoActual << endl;
    cout << "Ubicacion: " << getUbicacion() << endl;
}

void Paquete::mostrarBitacora() {
    cout << "Bitacora del paquete " << codigoUnico << " (estado actual: " << estadoActual << ")" << endl;
    if (bitacora.vacia()) {
        cout << "El paquete no tiene cambios de estado registrados." << endl;
        return;
    }
    int numero = 1;
    for (Nodo<RegistroEstado*>* n = bitacora.getPrimero(); n != nullptr; n = n->getSiguiente()) {
        cout << numero++ << ". ";
        n->getDato()->mostrarDatos();
    }
}
