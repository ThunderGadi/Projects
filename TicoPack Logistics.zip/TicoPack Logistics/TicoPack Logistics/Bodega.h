#ifndef BODEGA_H
#define BODEGA_H

#include <string>
#include "Celda.h"

using namespace std;

class Paquete;

class Bodega {
private:
    string codigo;
    string nombre;
    int tipo;
    int filas;
    int columnas;
    Celda** matriz;

public:
    Bodega(string codigo, string nombre, int tipo, int filas, int columnas);
    ~Bodega();


    string getCodigo();
    string getNombre();
    int getTipo();
    string getNombreTipo();
    int getFilas();
    int getColumnas();
    int getTotalCeldas();

    bool esValida();
    bool esCompatible(int categoria);
    bool posicionValida(int fila, int columna);
    bool estaDisponible(int fila, int columna);
    Paquete* getPaquete(int fila, int columna);
    string nombreCelda(int fila, int columna);

    bool asignarPaquete(int fila, int columna, Paquete* paquete);
    bool liberarCelda(int fila, int columna);
    bool primeraCeldaLibre(int& fila, int& columna);

    int contarOcupadas();
    int contarLibres();
    double porcentajeOcupacion();
    double porcentajeDisponible();

    void mostrarDatos();
    void mostrarOcupacion();
    void mostrarMatriz();
};

#endif
