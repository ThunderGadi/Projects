#ifndef CLIENTE_H
#define CLIENTE_H

#include <string>

using namespace std;

class Cliente {
protected:
    string idCliente;
    string nombre;
    string telefono;
    string correo;

    void mostrarDatosBase();

public:
    Cliente(string idCliente, string nombre, string telefono, string correo);

    virtual ~Cliente();

    string getIdCliente();
    string getNombre();
    string getTelefono();
    string getCorreo();

    virtual string getTipo() = 0;
    virtual double aplicarDescuento(double costoBase);
    virtual void mostrar() = 0;
};

#endif
