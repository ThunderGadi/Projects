#ifndef SISTEMA_H
#define SISTEMA_H

#include <string>
#include "Lista.h"

using namespace std;

class CentroDistribucion;
class Cliente;
class Colaborador;
class Bodega;
class Paquete;
class Solicitud;
class Despacho;

class Sistema {
private:
    Lista<CentroDistribucion*> centros;
    bool datosPruebaCargados;

    bool esEspacio(char c);
    string recortar(const string& texto);
    bool esDigito(char c);
    bool esEnteroValido(const string& texto);
    bool esDecimalValido(const string& texto);
    bool esBisiesto(int anio);
    bool fechaValida(const string& fecha);
    bool horaValida(const string& hora);
    bool correoValido(const string& correo);
    bool telefonoValido(const string& telefono);

    string leerLinea(const string& mensaje);
    string leerTexto(const string& mensaje);
    int leerEntero(const string& mensaje);
    int leerEnteroRango(const string& mensaje, int minimo, int maximo);
    double leerDecimal(const string& mensaje);
    double leerDecimalPositivo(const string& mensaje);
    double leerDecimalRango(const string& mensaje, double minimo, double maximo);
    string leerFecha(const string& mensaje);
    string leerHora(const string& mensaje);
    string leerCorreo(const string& mensaje);
    string leerTelefono(const string& mensaje);
    bool confirmar(const string& mensaje);
    void pausa();
    void titulo(const string& texto);

    CentroDistribucion* buscarCentroPorCodigo(const string& codigo);
    Paquete* buscarPaqueteGlobal(const string& codigo);
    Solicitud* buscarSolicitudGlobal(const string& codigo);
    Despacho* buscarDespachoGlobal(const string& codigo);

    CentroDistribucion* seleccionarCentro();
    Cliente* seleccionarCliente(CentroDistribucion* centro);
    Colaborador* seleccionarColaborador(CentroDistribucion* centro);
    Bodega* seleccionarBodega(CentroDistribucion* centro);
    Paquete* seleccionarPaquete();
    Solicitud* seleccionarSolicitud();
    Despacho* seleccionarDespacho();
    bool seleccionarCeldaDisponible(Bodega* bodega, int& fila, int& columna);
    void listarBodegasCompatibles(CentroDistribucion* centro, int categoria);

    void menuPrincipal();

    void menuCentros();
    void registrarCentro();
    void buscarCentro();
    void mostrarCentros();
    void eliminarCentro();

    void menuClientes();
    void registrarCliente();
    void buscarCliente();
    void mostrarClientes();
    void eliminarCliente();

    void menuColaboradores();
    void registrarColaborador();
    void buscarColaborador();
    void mostrarColaboradores();
    void eliminarColaborador();

    void menuBodegas();
    void registrarBodega();
    void buscarBodega();
    void mostrarBodegas();
    void consultarCelda();
    void eliminarBodega();

    void menuPaquetes();
    void registrarPaquete();
    void buscarPaquete();
    void mostrarPaquetes();
    void almacenarPaquete(Paquete* paquete);
    void reubicarPaquete();
    void registrarIncidencia();
    void resolverIncidencia();
    void eliminarPaquete();

    void menuSolicitudes();
    void crearSolicitud();
    void buscarSolicitud();
    void mostrarSolicitudes();
    void aprobarSolicitud();
    void rechazarOAnularSolicitud(bool rechazar);

    void menuDespachos();
    void buscarDespacho();
    void mostrarDespachos();
    void finalizarDespacho();

    void menuReportes();
    void reporteHistorialCliente();
    void reporteClientesPorEnvios();
    void reporteBitacoraPaquete();
    void reporteDespachoPaquete();
    void reporteOcupacionBodegas();
    void reporteDespachosPorColaborador();

    void cargarDatosPrueba();

public:
    Sistema();
    ~Sistema();


    void iniciar();
};

#endif
