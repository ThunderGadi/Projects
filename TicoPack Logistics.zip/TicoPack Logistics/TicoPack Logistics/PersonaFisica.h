#ifndef PERSONAFISICA_H
#define PERSONAFISICA_H

#include "Cliente.h"

class PersonaFisica : public Cliente {
public:
    PersonaFisica(string idCliente, string nombre, string telefono, string correo);

    string getTipo() override;
    void mostrar() override;
};

#endif
