#ifndef CENTRODISTRIBUCION_H
#define CENTRODISTRIBUCION_H

#include <string>
#include "Lista.h"

using namespace std;

class Cliente;
class Colaborador;
class Paquete;
class Bodega;
class Solicitud;
class Despacho;

class CentroDistribucion {
private:
    string codigoUnico;
    string nombre;
    string provincia;
    string direccion;
    string telefono;

    Lista<Cliente*> clientes;
    Lista<Colaborador*> colaboradores;
    Lista<Bodega*> bodegas;
    Lista<Paquete*> paquetes;
    Lista<Solicitud*> solicitudes;
    Lista<Despacho*> despachos;

public:
    CentroDistribucion(const string& codigoUnico, const string& nombre, const string& provincia,
        const string& direccion, const string& telefono);
    ~CentroDistribucion();


    string getCodigoUnico();
    string getNombre();
    string getProvincia();
    string getDireccion();
    string getTelefono();

    Lista<Cliente*>& getClientes();
    Lista<Colaborador*>& getColaboradores();
    Lista<Bodega*>& getBodegas();
    Lista<Paquete*>& getPaquetes();
    Lista<Solicitud*>& getSolicitudes();
    Lista<Despacho*>& getDespachos();

    Cliente* buscarCliente(const string& identificacion);
    Colaborador* buscarColaborador(const string& identificacion);
    Bodega* buscarBodega(const string& codigo);
    Paquete* buscarPaquete(const string& codigo);
    Solicitud* buscarSolicitud(const string& codigo);
    Despacho* buscarDespacho(const string& codigo);

    bool agregarCliente(Cliente* cliente);
    bool agregarColaborador(Colaborador* colaborador);
    bool agregarBodega(Bodega* bodega);
    bool agregarPaquete(Paquete* paquete);

    bool estaVacio();
    bool clienteTieneDependencias(Cliente* cliente);
    bool colaboradorTieneDependencias(Colaborador* colaborador);
    bool bodegaTienePaquetes(Bodega* bodega);
    bool paqueteTieneDependencias(Paquete* paquete);

    bool eliminarCliente(Cliente* cliente);
    bool eliminarColaborador(Colaborador* colaborador);
    bool eliminarBodega(Bodega* bodega);
    bool eliminarPaquete(Paquete* paquete);

    Bodega* recomendarBodega(int categoria);
    bool hayBodegaCompatibleDisponible(int categoria);

    bool tieneSolicitudPendiente(Paquete* paquete);
    bool tieneSolicitudAprobada(Paquete* paquete);
    string validarNuevaSolicitud(Paquete* paquete, Colaborador* colaborador);
    string validarAprobacion(Solicitud* solicitud);
    Solicitud* crearSolicitud(const string& codigo, Paquete* paquete, Colaborador* colaborador,
        const string& destino, const string& fecha, string& error);
    Despacho* aprobarSolicitud(Solicitud* solicitud, const string& codigoDespacho,
        const string& fecha, const string& hora, string& error);

    int contarDespachosFinalizados(Cliente* cliente);

    void mostrarDatos();
};

#endif
