#include "RegistroEstado.h"
#include "Colaborador.h"

#include <iostream>

using namespace std;

RegistroEstado::RegistroEstado(string estadoAnterior, string estadoNuevo, string fecha, Colaborador* colaborador) {
    this->estadoAnterior = estadoAnterior;
    this->estadoNuevo = estadoNuevo;
    this->fecha = fecha;
    this->colaborador = colaborador;
}

string RegistroEstado::getEstadoAnterior() {
    return estadoAnterior;
}

string RegistroEstado::getEstadoNuevo() {
    return estadoNuevo;
}

string RegistroEstado::getFecha() {
    return fecha;
}

Colaborador* RegistroEstado::getColaborador() {
    return colaborador;
}

void RegistroEstado::mostrarDatos() {
    cout << "Estado anterior: " << estadoAnterior
         << " | Nuevo estado: " << estadoNuevo
         << " | Fecha: " << fecha
         << " | Colaborador: ";
    if (colaborador != nullptr) {
        cout << colaborador->getNombre() << " (" << colaborador->getIdColaborador() << ")";
    } else {
        cout << "No asignado";
    }
    cout << endl;
}
