#ifndef CATEGORIA_H
#define CATEGORIA_H

#include <string>

using namespace std;

class Categoria {
private:
    static const double TARIFA_GENERAL;
    static const double TARIFA_FRAGIL;
    static const double TARIFA_TECNOLOGIA;
    static const double TARIFA_DOCUMENTOS;

public:
    static const int GENERAL = 1;
    static const int FRAGIL = 2;
    static const int TECNOLOGIA = 3;
    static const int DOCUMENTOS = 4;

    static bool esValida(int codigo);
    static string nombre(int codigo);
    static double tarifaPorKilogramo(int codigo);
    static void mostrarOpciones();
};

#endif
