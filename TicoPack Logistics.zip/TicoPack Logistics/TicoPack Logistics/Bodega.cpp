#include "Bodega.h"
#include "Paquete.h"
#include "Categoria.h"

#include <iostream>
#include <iomanip>

using namespace std;

Bodega::Bodega(string codigo, string nombre, int tipo, int filas, int columnas) {
    this->codigo = codigo;
    this->nombre = nombre;
    this->tipo = tipo;
    this->filas = 0;
    this->columnas = 0;
    matriz = nullptr;

    if (!Categoria::esValida(tipo) || filas <= 0 || columnas <= 0) {
        return;
    }

    this->filas = filas;
    this->columnas = columnas;
    matriz = new Celda*[filas];
    for (int i = 0; i < filas; i++) {
        matriz[i] = new Celda[columnas];
    }
}

Bodega::~Bodega() {
    if (matriz != nullptr) {
        for (int i = 0; i < filas; i++) {
            delete[] matriz[i];
        }
        delete[] matriz;
        matriz = nullptr;
    }
}

string Bodega::getCodigo() {
    return codigo;
}

string Bodega::getNombre() {
    return nombre;
}

int Bodega::getTipo() {
    return tipo;
}

string Bodega::getNombreTipo() {
    return Categoria::nombre(tipo);
}

int Bodega::getFilas() {
    return filas;
}

int Bodega::getColumnas() {
    return columnas;
}

int Bodega::getTotalCeldas() {
    return filas * columnas;
}

bool Bodega::esValida() {
    return matriz != nullptr;
}

bool Bodega::esCompatible(int categoria) {
    return tipo == categoria;
}

bool Bodega::posicionValida(int fila, int columna) {
    return matriz != nullptr && fila >= 0 && fila < filas && columna >= 0 && columna < columnas;
}

bool Bodega::estaDisponible(int fila, int columna) {
    return posicionValida(fila, columna) && matriz[fila][columna].estaLibre();
}

Paquete* Bodega::getPaquete(int fila, int columna) {
    if (!posicionValida(fila, columna)) return nullptr;
    return matriz[fila][columna].getPaquete();
}

string Bodega::nombreCelda(int fila, int columna) {
    return codigo + "-" + to_string(fila) + "-" + to_string(columna);
}

bool Bodega::asignarPaquete(int fila, int columna, Paquete* paquete) {
    if (!posicionValida(fila, columna) || paquete == nullptr) return false;
    return matriz[fila][columna].asignarPaquete(paquete);
}

bool Bodega::liberarCelda(int fila, int columna) {
    if (!posicionValida(fila, columna) || matriz[fila][columna].estaLibre()) return false;
    matriz[fila][columna].liberar();
    return true;
}

bool Bodega::primeraCeldaLibre(int& fila, int& columna) {
    for (int i = 0; i < filas; i++) {
        for (int j = 0; j < columnas; j++) {
            if (matriz[i][j].estaLibre()) {
                fila = i;
                columna = j;
                return true;
            }
        }
    }
    return false;
}

int Bodega::contarOcupadas() {
    int cantidad = 0;
    for (int i = 0; i < filas; i++) {
        for (int j = 0; j < columnas; j++) {
            if (!matriz[i][j].estaLibre()) cantidad++;
        }
    }
    return cantidad;
}

int Bodega::contarLibres() {
    return getTotalCeldas() - contarOcupadas();
}

double Bodega::porcentajeOcupacion() {
    if (getTotalCeldas() == 0) return 0.0;
    return (double)contarOcupadas() / getTotalCeldas() * 100.0;
}

double Bodega::porcentajeDisponible() {
    if (getTotalCeldas() == 0) return 0.0;
    return (double)contarLibres() / getTotalCeldas() * 100.0;
}

void Bodega::mostrarDatos() {
    cout << "Codigo: " << codigo << endl;
    cout << "Nombre: " << nombre << endl;
    cout << "Tipo: " << tipo << " - " << getNombreTipo() << endl;
    cout << "Distribucion: " << filas << " filas x " << columnas << " columnas" << endl;
}

void Bodega::mostrarOcupacion() {
    cout << fixed << setprecision(2);
    cout << "Bodega " << codigo << " (" << nombre << ", " << getNombreTipo() << ")"
        << " | Total: " << getTotalCeldas()
        << " | Ocupadas: " << contarOcupadas()
        << " | Disponibles: " << contarLibres()
        << " | Ocupacion: " << porcentajeOcupacion() << "%"
        << " | Disponible: " << porcentajeDisponible() << "%" << endl;
}

void Bodega::mostrarMatriz() {
    if (matriz == nullptr) {
        cout << "La bodega no tiene una matriz valida." << endl;
        return;
    }

    int ancho = 5;
    for (int i = 0; i < filas; i++) {
        for (int j = 0; j < columnas; j++) {
            int largoNombre = (int)nombreCelda(i, j).length();
            if (largoNombre > ancho) ancho = largoNombre;
            if (!matriz[i][j].estaLibre()) {
                int largoCodigo = (int)matriz[i][j].getPaquete()->getCodigoUnico().length();
                if (largoCodigo > ancho) ancho = largoCodigo;
            }
        }
    }

    string separador = "+";
    for (int j = 0; j < columnas; j++) {
        separador += string(ancho + 2, '-') + "+";
    }

    cout << "\nBodega " << codigo << " - " << nombre << " (" << getNombreTipo() << ")" << endl;
    cout << "Formato de celda: CODIGO-FILA-COLUMNA" << endl;
    cout << separador << endl;
    for (int i = 0; i < filas; i++) {
        cout << "|";
        for (int j = 0; j < columnas; j++) {
            cout << " " << left << setw(ancho) << nombreCelda(i, j) << " |";
        }
        cout << endl << "|";
        for (int j = 0; j < columnas; j++) {
            string contenido = matriz[i][j].estaLibre() ? "LIBRE" : matriz[i][j].getPaquete()->getCodigoUnico();
            cout << " " << left << setw(ancho) << contenido << " |";
        }
        cout << endl << separador << endl;
    }
    cout << right;
    cout << fixed << setprecision(2) << "Ocupadas: " << contarOcupadas() << "/" << getTotalCeldas()
         << " (" << porcentajeOcupacion() << "%)" << endl;
}
