#include "CentroDistribucion.h"
#include "Cliente.h"
#include "Colaborador.h"
#include "Paquete.h"
#include "Bodega.h"
#include "Solicitud.h"
#include "Despacho.h"
#include "RegistroEstado.h"

#include <iostream>

using namespace std;

CentroDistribucion::CentroDistribucion(const string& codigoUnico, const string& nombre, const string& provincia,
    const string& direccion, const string& telefono) {
    this->codigoUnico = codigoUnico;
    this->nombre = nombre;
    this->provincia = provincia;
    this->direccion = direccion;
    this->telefono = telefono;
}

CentroDistribucion::~CentroDistribucion() {
    while (!despachos.vacia()) delete despachos.extraerPrimero();
    while (!solicitudes.vacia()) delete solicitudes.extraerPrimero();
    while (!paquetes.vacia()) delete paquetes.extraerPrimero();
    while (!bodegas.vacia()) delete bodegas.extraerPrimero();
    while (!clientes.vacia()) delete clientes.extraerPrimero();
    while (!colaboradores.vacia()) delete colaboradores.extraerPrimero();
}

string CentroDistribucion::getCodigoUnico() {
    return codigoUnico;
}

string CentroDistribucion::getNombre() {
    return nombre;
}

string CentroDistribucion::getProvincia() {
    return provincia;
}

string CentroDistribucion::getDireccion() {
    return direccion;
}

string CentroDistribucion::getTelefono() {
    return telefono;
}

Lista<Cliente*>& CentroDistribucion::getClientes() {
    return clientes;
}

Lista<Colaborador*>& CentroDistribucion::getColaboradores() {
    return colaboradores;
}

Lista<Bodega*>& CentroDistribucion::getBodegas() {
    return bodegas;
}

Lista<Paquete*>& CentroDistribucion::getPaquetes() {
    return paquetes;
}

Lista<Solicitud*>& CentroDistribucion::getSolicitudes() {
    return solicitudes;
}

Lista<Despacho*>& CentroDistribucion::getDespachos() {
    return despachos;
}

Cliente* CentroDistribucion::buscarCliente(const string& identificacion) {
    for (Nodo<Cliente*>* n = clientes.getPrimero(); n != nullptr; n = n->getSiguiente()) {
        if (n->getDato()->getIdCliente() == identificacion) return n->getDato();
    }
    return nullptr;
}

Colaborador* CentroDistribucion::buscarColaborador(const string& identificacion) {
    for (Nodo<Colaborador*>* n = colaboradores.getPrimero(); n != nullptr; n = n->getSiguiente()) {
        if (n->getDato()->getIdColaborador() == identificacion) return n->getDato();
    }
    return nullptr;
}

Bodega* CentroDistribucion::buscarBodega(const string& codigo) {
    for (Nodo<Bodega*>* n = bodegas.getPrimero(); n != nullptr; n = n->getSiguiente()) {
        if (n->getDato()->getCodigo() == codigo) return n->getDato();
    }
    return nullptr;
}

Paquete* CentroDistribucion::buscarPaquete(const string& codigo) {
    for (Nodo<Paquete*>* n = paquetes.getPrimero(); n != nullptr; n = n->getSiguiente()) {
        if (n->getDato()->getCodigoUnico() == codigo) return n->getDato();
    }
    return nullptr;
}

Solicitud* CentroDistribucion::buscarSolicitud(const string& codigo) {
    for (Nodo<Solicitud*>* n = solicitudes.getPrimero(); n != nullptr; n = n->getSiguiente()) {
        if (n->getDato()->getCodigo() == codigo) return n->getDato();
    }
    return nullptr;
}

Despacho* CentroDistribucion::buscarDespacho(const string& codigo) {
    for (Nodo<Despacho*>* n = despachos.getPrimero(); n != nullptr; n = n->getSiguiente()) {
        if (n->getDato()->getCodigo() == codigo) return n->getDato();
    }
    return nullptr;
}

bool CentroDistribucion::agregarCliente(Cliente* cliente) {
    if (cliente == nullptr || buscarCliente(cliente->getIdCliente()) != nullptr) return false;
    clientes.agregar(cliente);
    return true;
}

bool CentroDistribucion::agregarColaborador(Colaborador* colaborador) {
    if (colaborador == nullptr || buscarColaborador(colaborador->getIdColaborador()) != nullptr) return false;
    colaboradores.agregar(colaborador);
    return true;
}

bool CentroDistribucion::agregarBodega(Bodega* bodega) {
    if (bodega == nullptr || !bodega->esValida() || buscarBodega(bodega->getCodigo()) != nullptr) return false;
    bodegas.agregar(bodega);
    return true;
}

bool CentroDistribucion::agregarPaquete(Paquete* paquete) {
    if (paquete == nullptr || paquete->getCentro() != this || !clientes.contiene(paquete->getCliente())) return false;
    if (buscarPaquete(paquete->getCodigoUnico()) != nullptr) return false;
    paquetes.agregar(paquete);
    return true;
}

bool CentroDistribucion::estaVacio() {
    return clientes.vacia() && colaboradores.vacia() && bodegas.vacia() &&
        paquetes.vacia() && solicitudes.vacia() && despachos.vacia();
}

bool CentroDistribucion::clienteTieneDependencias(Cliente* cliente) {
    for (Nodo<Paquete*>* n = paquetes.getPrimero(); n != nullptr; n = n->getSiguiente()) {
        if (n->getDato()->getCliente() == cliente) return true;
    }
    for (Nodo<Solicitud*>* n = solicitudes.getPrimero(); n != nullptr; n = n->getSiguiente()) {
        if (n->getDato()->getCliente() == cliente) return true;
    }
    for (Nodo<Despacho*>* n = despachos.getPrimero(); n != nullptr; n = n->getSiguiente()) {
        if (n->getDato()->getCliente() == cliente) return true;
    }
    return false;
}

bool CentroDistribucion::colaboradorTieneDependencias(Colaborador* colaborador) {
    for (Nodo<Solicitud*>* n = solicitudes.getPrimero(); n != nullptr; n = n->getSiguiente()) {
        if (n->getDato()->getColaborador() == colaborador) return true;
    }
    for (Nodo<Despacho*>* n = despachos.getPrimero(); n != nullptr; n = n->getSiguiente()) {
        if (n->getDato()->getColaborador() == colaborador) return true;
    }
    for (Nodo<Paquete*>* n = paquetes.getPrimero(); n != nullptr; n = n->getSiguiente()) {
        Lista<RegistroEstado*>& bitacora = n->getDato()->getBitacora();
        for (Nodo<RegistroEstado*>* r = bitacora.getPrimero(); r != nullptr; r = r->getSiguiente()) {
            if (r->getDato()->getColaborador() == colaborador) return true;
        }
    }
    return false;
}

bool CentroDistribucion::bodegaTienePaquetes(Bodega* bodega) {
    if (bodega->contarOcupadas() > 0) return true;
    for (Nodo<Paquete*>* n = paquetes.getPrimero(); n != nullptr; n = n->getSiguiente()) {
        if (n->getDato()->getBodega() == bodega) return true;
    }
    return false;
}

bool CentroDistribucion::paqueteTieneDependencias(Paquete* paquete) {
    if (paquete->getDespacho() != nullptr) return true;
    for (Nodo<Solicitud*>* n = solicitudes.getPrimero(); n != nullptr; n = n->getSiguiente()) {
        if (n->getDato()->getPaquete() == paquete) return true;
    }
    for (Nodo<Despacho*>* n = despachos.getPrimero(); n != nullptr; n = n->getSiguiente()) {
        if (n->getDato()->getPaquete() == paquete) return true;
    }
    return false;
}

bool CentroDistribucion::eliminarCliente(Cliente* cliente) {
    if (cliente == nullptr || !clientes.contiene(cliente) || clienteTieneDependencias(cliente)) return false;
    clientes.eliminarDato(cliente);
    delete cliente;
    return true;
}

bool CentroDistribucion::eliminarColaborador(Colaborador* colaborador) {
    if (colaborador == nullptr || !colaboradores.contiene(colaborador) || colaboradorTieneDependencias(colaborador)) return false;
    colaboradores.eliminarDato(colaborador);
    delete colaborador;
    return true;
}

bool CentroDistribucion::eliminarBodega(Bodega* bodega) {
    if (bodega == nullptr || !bodegas.contiene(bodega) || bodegaTienePaquetes(bodega)) return false;
    bodegas.eliminarDato(bodega);
    delete bodega;
    return true;
}

bool CentroDistribucion::eliminarPaquete(Paquete* paquete) {
    if (paquete == nullptr || !paquetes.contiene(paquete)) return false;
    if (paquete->getEstadoActual() != Paquete::RECIBIDO || paquete->tieneUbicacion() || paqueteTieneDependencias(paquete)) return false;
    paquetes.eliminarDato(paquete);
    delete paquete;
    return true;
}

Bodega* CentroDistribucion::recomendarBodega(int categoria) {
    Bodega* recomendada = nullptr;
    for (Nodo<Bodega*>* n = bodegas.getPrimero(); n != nullptr; n = n->getSiguiente()) {
        Bodega* bodega = n->getDato();
        if (bodega->esCompatible(categoria) && bodega->contarLibres() > 0) {
            if (recomendada == nullptr || bodega->porcentajeDisponible() > recomendada->porcentajeDisponible()) {
                recomendada = bodega;
            }
        }
    }
    return recomendada;
}

bool CentroDistribucion::hayBodegaCompatibleDisponible(int categoria) {
    return recomendarBodega(categoria) != nullptr;
}

bool CentroDistribucion::tieneSolicitudPendiente(Paquete* paquete) {
    for (Nodo<Solicitud*>* n = solicitudes.getPrimero(); n != nullptr; n = n->getSiguiente()) {
        if (n->getDato()->getPaquete() == paquete && n->getDato()->getEstado() == Solicitud::PENDIENTE) return true;
    }
    return false;
}

bool CentroDistribucion::tieneSolicitudAprobada(Paquete* paquete) {
    for (Nodo<Solicitud*>* n = solicitudes.getPrimero(); n != nullptr; n = n->getSiguiente()) {
        if (n->getDato()->getPaquete() == paquete && n->getDato()->getEstado() == Solicitud::APROBADA) return true;
    }
    return false;
}

string CentroDistribucion::validarNuevaSolicitud(Paquete* paquete, Colaborador* colaborador) {
    if (paquete == nullptr || !paquetes.contiene(paquete)) return "El paquete no pertenece a este centro.";
    if (paquete->getEstadoActual() != Paquete::ALMACENADO) return "Solo se puede crear una solicitud para un paquete en estado Almacenado.";
    if (tieneSolicitudPendiente(paquete)) return "El paquete ya tiene una solicitud Pendiente.";
    if (tieneSolicitudAprobada(paquete) || paquete->getDespacho() != nullptr) return "El paquete ya tiene una solicitud Aprobada y un despacho asociado.";
    if (paquete->getCliente() == nullptr || !clientes.contiene(paquete->getCliente())) return "El cliente propietario no pertenece a este centro.";
    if (colaborador == nullptr || !colaboradores.contiene(colaborador)) return "El colaborador responsable no pertenece a este centro.";
    return "";
}

Solicitud* CentroDistribucion::crearSolicitud(const string& codigo, Paquete* paquete, Colaborador* colaborador,
    const string& destino, const string& fecha, string& error) {
    error = validarNuevaSolicitud(paquete, colaborador);
    if (!error.empty()) return nullptr;
    Solicitud* solicitud = new Solicitud(codigo, paquete, colaborador, this, destino, fecha);
    solicitudes.agregar(solicitud);
    return solicitud;
}

string CentroDistribucion::validarAprobacion(Solicitud* solicitud) {
    if (solicitud == nullptr || !solicitudes.contiene(solicitud)) return "La solicitud no pertenece a este centro.";
    if (solicitud->getEstado() != Solicitud::PENDIENTE) return "Solo se pueden aprobar solicitudes en estado Pendiente.";
    Paquete* paquete = solicitud->getPaquete();
    if (paquete == nullptr || paquete->getEstadoActual() != Paquete::ALMACENADO) return "El paquete debe encontrarse en estado Almacenado para aprobar la solicitud.";
    if (paquete->getDespacho() != nullptr) return "El paquete ya tiene un despacho asociado.";
    if (!colaboradores.contiene(solicitud->getColaborador())) return "El colaborador responsable ya no pertenece a este centro.";
    return "";
}

Despacho* CentroDistribucion::aprobarSolicitud(Solicitud* solicitud, const string& codigoDespacho,
    const string& fecha, const string& hora, string& error) {
    error = validarAprobacion(solicitud);
    if (!error.empty()) return nullptr;
    Despacho* despacho = new Despacho(codigoDespacho, solicitud, fecha, hora);
    if (!solicitud->getPaquete()->iniciarTransito(despacho, solicitud->getColaborador(), fecha + " " + hora)) {
        delete despacho;
        error = "No se pudo cambiar el paquete a En transito.";
        return nullptr;
    }
    solicitud->aprobar();
    despachos.agregar(despacho);
    return despacho;
}

int CentroDistribucion::contarDespachosFinalizados(Cliente* cliente) {
    int cantidad = 0;
    for (Nodo<Despacho*>* n = despachos.getPrimero(); n != nullptr; n = n->getSiguiente()) {
        if (n->getDato()->getCliente() == cliente && n->getDato()->getEstado() == Despacho::FINALIZADO) cantidad++;
    }
    return cantidad;
}

void CentroDistribucion::mostrarDatos() {
    cout << "Codigo: " << codigoUnico << endl;
    cout << "Nombre: " << nombre << endl;
    cout << "Provincia: " << provincia << endl;
    cout << "Direccion: " << direccion << endl;
    cout << "Telefono: " << telefono << endl;
    cout << "Clientes: " << clientes.size()
         << " | Colaboradores: " << colaboradores.size()
         << " | Bodegas: " << bodegas.size()
         << " | Paquetes: " << paquetes.size()
         << " | Solicitudes: " << solicitudes.size()
         << " | Despachos: " << despachos.size() << endl;
}
