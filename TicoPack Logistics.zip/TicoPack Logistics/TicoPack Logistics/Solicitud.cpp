#include "Solicitud.h"
#include "Cliente.h"
#include "Colaborador.h"
#include "Paquete.h"
#include "CentroDistribucion.h"
#include "Categoria.h"

#include <iostream>
#include <iomanip>

using namespace std;

const string Solicitud::PENDIENTE = "Pendiente";
const string Solicitud::APROBADA = "Aprobada";
const string Solicitud::RECHAZADA = "Rechazada";
const string Solicitud::ANULADA = "Anulada";

Solicitud::Solicitud(string codigo, Paquete* paquete, Colaborador* colaborador,
    CentroDistribucion* centroOrigen, string destino, string fecha) {
    this->codigo = codigo;
    this->paquete = paquete;
    this->cliente = paquete != nullptr ? paquete->getCliente() : nullptr;
    this->colaborador = colaborador;
    this->centroOrigen = centroOrigen;
    this->destino = destino;
    this->fecha = fecha;
    estado = PENDIENTE;
    costoEstimado = calcularCosto();
}

double Solicitud::calcularCosto() {
    if (paquete == nullptr || cliente == nullptr) return 0.0;
    double costoBase = paquete->getPeso() * Categoria::tarifaPorKilogramo(paquete->getCategoria());
    return cliente->aplicarDescuento(costoBase);
}

string Solicitud::getCodigo() {
    return codigo;
}

Cliente* Solicitud::getCliente() {
    return cliente;
}

Paquete* Solicitud::getPaquete() {
    return paquete;
}

Colaborador* Solicitud::getColaborador() {
    return colaborador;
}

CentroDistribucion* Solicitud::getCentroOrigen() {
    return centroOrigen;
}

string Solicitud::getDestino() {
    return destino;
}

string Solicitud::getFecha() {
    return fecha;
}

double Solicitud::getCostoEstimado() {
    return costoEstimado;
}

string Solicitud::getEstado() {
    return estado;
}

bool Solicitud::cambiarEstado(const string& nuevoEstado) {
    if (estado != PENDIENTE) return false;
    if (nuevoEstado != APROBADA && nuevoEstado != RECHAZADA && nuevoEstado != ANULADA) return false;
    estado = nuevoEstado;
    return true;
}

bool Solicitud::aprobar() {
    return cambiarEstado(APROBADA);
}

bool Solicitud::rechazar() {
    return cambiarEstado(RECHAZADA);
}

bool Solicitud::anular() {
    return cambiarEstado(ANULADA);
}

void Solicitud::mostrarDatos() {
    cout << "Codigo de solicitud: " << codigo << endl;
    cout << "Estado: " << estado << endl;
    cout << "Cliente: ";
    if (cliente != nullptr) cout << cliente->getNombre() << " (" << cliente->getIdCliente() << ", " << cliente->getTipo() << ")";
    cout << endl;
    cout << "Paquete: " << (paquete != nullptr ? paquete->getCodigoUnico() : "N/A") << endl;
    cout << "Colaborador responsable: ";
    if (colaborador != nullptr) cout << colaborador->getNombre() << " (" << colaborador->getIdColaborador() << ")";
    cout << endl;
    cout << "Centro de origen: ";
    if (centroOrigen != nullptr) cout << centroOrigen->getNombre() << " (" << centroOrigen->getCodigoUnico() << ")";
    cout << endl;
    cout << "Destino de entrega: " << destino << endl;
    cout << "Fecha de solicitud: " << fecha << endl;
    cout << "Costo estimado: " << fixed << setprecision(2) << costoEstimado << " colones" << endl;
}

void Solicitud::mostrarResumen() {
    cout << "Solicitud " << codigo
         << " | Paquete: " << (paquete != nullptr ? paquete->getCodigoUnico() : "N/A")
         << " | Fecha: " << fecha
         << " | Estado: " << estado
         << " | Costo: " << fixed << setprecision(2) << costoEstimado << endl;
}
