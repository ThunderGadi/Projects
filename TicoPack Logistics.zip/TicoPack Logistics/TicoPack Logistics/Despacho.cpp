#include "Despacho.h"
#include "Solicitud.h"
#include "Paquete.h"
#include "Cliente.h"
#include "Colaborador.h"
#include "CentroDistribucion.h"

#include <iostream>

using namespace std;

const string Despacho::EN_PROCESO = "En proceso";
const string Despacho::FINALIZADO = "Finalizado";

Despacho::Despacho(string codigo, Solicitud* solicitud, string fecha, string hora) {
    this->codigo = codigo;
    this->solicitud = solicitud;
    this->paquete = solicitud != nullptr ? solicitud->getPaquete() : nullptr;
    this->cliente = solicitud != nullptr ? solicitud->getCliente() : nullptr;
    this->colaborador = solicitud != nullptr ? solicitud->getColaborador() : nullptr;
    this->centroOrigen = solicitud != nullptr ? solicitud->getCentroOrigen() : nullptr;
    this->destino = solicitud != nullptr ? solicitud->getDestino() : "";
    this->fecha = fecha;
    this->hora = hora;
    estado = EN_PROCESO;
}

string Despacho::getCodigo() {
    return codigo;
}

Solicitud* Despacho::getSolicitud() {
    return solicitud;
}

Paquete* Despacho::getPaquete() {
    return paquete;
}

Cliente* Despacho::getCliente() {
    return cliente;
}

Colaborador* Despacho::getColaborador() {
    return colaborador;
}

CentroDistribucion* Despacho::getCentroOrigen() {
    return centroOrigen;
}

string Despacho::getDestino() {
    return destino;
}

string Despacho::getFecha() {
    return fecha;
}

string Despacho::getHora() {
    return hora;
}

string Despacho::getEstado() {
    return estado;
}

bool Despacho::puedeFinalizar() {
    return estado == EN_PROCESO && paquete != nullptr && paquete->getEstadoActual() == Paquete::EN_TRANSITO;
}

bool Despacho::finalizar(const string& fechaEntrega) {
    if (!puedeFinalizar()) return false;
    if (!paquete->entregar(colaborador, fechaEntrega)) return false;
    estado = FINALIZADO;
    return true;
}

void Despacho::mostrarDatos() {
    cout << "Codigo de despacho: " << codigo << endl;
    cout << "Estado: " << estado << endl;
    cout << "Solicitud asociada: " << (solicitud != nullptr ? solicitud->getCodigo() : "N/A") << endl;
    cout << "Paquete: " << (paquete != nullptr ? paquete->getCodigoUnico() : "N/A");
    if (paquete != nullptr) cout << " (estado: " << paquete->getEstadoActual() << ")";
    cout << endl;
    cout << "Cliente: ";
    if (cliente != nullptr) cout << cliente->getNombre() << " (" << cliente->getIdCliente() << ")";
    cout << endl;
    cout << "Colaborador responsable: ";
    if (colaborador != nullptr) cout << colaborador->getNombre() << " (" << colaborador->getIdColaborador() << ")";
    cout << endl;
    cout << "Centro de origen: ";
    if (centroOrigen != nullptr) cout << centroOrigen->getNombre() << " (" << centroOrigen->getCodigoUnico() << ")";
    cout << endl;
    cout << "Destino: " << destino << endl;
    cout << "Fecha: " << fecha << endl;
    cout << "Hora: " << hora << endl;
}

void Despacho::mostrarResumen() {
    cout << "Despacho " << codigo
         << " | Paquete: " << (paquete != nullptr ? paquete->getCodigoUnico() : "N/A")
         << " | Fecha: " << fecha << " " << hora
         << " | Estado: " << estado << endl;
}
