#ifndef EMPRESA_H
#define EMPRESA_H

#include "Cliente.h"

class Empresa : public Cliente {
private:
    string actividadEconomica;
    double porcentajeDescuento;

public:
    Empresa(string idCliente, string nombre, string telefono, string correo,
        string actividadEconomica, double porcentajeDescuento);

    string getActividadEconomica();
    double getPorcentajeDescuento();

    static bool descuentoValido(double porcentaje);

    string getTipo() override;
    double aplicarDescuento(double costoBase) override;
    void mostrar() override;
};

#endif
