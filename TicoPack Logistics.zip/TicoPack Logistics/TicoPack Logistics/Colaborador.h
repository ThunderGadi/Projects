#ifndef COLABORADOR_H
#define COLABORADOR_H

#include <string>

using namespace std;

class Colaborador {
private:
    string idColaborador;
    string nombre;
    string fechaIngreso;
    string puesto;

public:
    Colaborador(string idColaborador, string nombre, string fechaIngreso, string puesto);

    string getIdColaborador();
    string getNombre();
    string getFechaIngreso();
    string getPuesto();

    void mostrarDatos();
};

#endif
