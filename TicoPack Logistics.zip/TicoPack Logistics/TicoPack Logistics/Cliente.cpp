#include "Cliente.h"

#include <iostream>

using namespace std;

Cliente::Cliente(string idCliente, string nombre, string telefono, string correo) {
    this->idCliente = idCliente;
    this->nombre = nombre;
    this->telefono = telefono;
    this->correo = correo;
}

Cliente::~Cliente() {
}

string Cliente::getIdCliente() {
    return idCliente;
}

string Cliente::getNombre() {
    return nombre;
}

string Cliente::getTelefono() {
    return telefono;
}

string Cliente::getCorreo() {
    return correo;
}

double Cliente::aplicarDescuento(double costoBase) {
    return costoBase;
}

void Cliente::mostrarDatosBase() {
    cout << "Tipo de cliente: " << getTipo() << endl;
    cout << "Identificacion: " << idCliente << endl;
    cout << "Nombre: " << nombre << endl;
    cout << "Telefono: " << telefono << endl;
    cout << "Correo: " << correo << endl;
}
