#ifndef CELDA_H
#define CELDA_H

class Paquete;

class Celda {
private:
    Paquete* paquete;

public:
    Celda();

    bool estaLibre() const;
    Paquete* getPaquete() const;
    bool asignarPaquete(Paquete* paquete);
    void liberar();
};

#endif
