#ifndef SOLICITUD_H
#define SOLICITUD_H

#include <string>

using namespace std;

class Cliente;
class Colaborador;
class Paquete;
class CentroDistribucion;

class Solicitud {
private:
    string codigo;
    Cliente* cliente;
    Paquete* paquete;
    Colaborador* colaborador;
    CentroDistribucion* centroOrigen;
    string destino;
    string fecha;
    double costoEstimado;
    string estado;

    double calcularCosto();
    bool cambiarEstado(const string& nuevoEstado);

public:
    static const string PENDIENTE;
    static const string APROBADA;
    static const string RECHAZADA;
    static const string ANULADA;

    Solicitud(string codigo, Paquete* paquete, Colaborador* colaborador,
        CentroDistribucion* centroOrigen, string destino, string fecha);

    string getCodigo();
    Cliente* getCliente();
    Paquete* getPaquete();
    Colaborador* getColaborador();
    CentroDistribucion* getCentroOrigen();
    string getDestino();
    string getFecha();
    double getCostoEstimado();
    string getEstado();

    bool aprobar();
    bool rechazar();
    bool anular();

    void mostrarDatos();
    void mostrarResumen();
};

#endif
