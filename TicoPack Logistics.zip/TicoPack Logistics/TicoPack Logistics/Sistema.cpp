#include "Sistema.h"
#include "CentroDistribucion.h"
#include "Cliente.h"
#include "PersonaFisica.h"
#include "Empresa.h"
#include "Colaborador.h"
#include "Bodega.h"
#include "Paquete.h"
#include "Solicitud.h"
#include "Despacho.h"
#include "RegistroEstado.h"
#include "Categoria.h"

#include <iostream>
#include <iomanip>
#include <string>

using namespace std;


bool Sistema::esEspacio(char c) {
    return c == ' ' || c == '\t' || c == '\r' || c == '\n';
}

string Sistema::recortar(const string& texto) {
    int inicio = 0;
    int fin = (int)texto.length() - 1;
    while (inicio <= fin && esEspacio(texto[inicio])) inicio++;
    while (fin >= inicio && esEspacio(texto[fin])) fin--;
    if (inicio > fin) return "";
    return texto.substr(inicio, fin - inicio + 1);
}

bool Sistema::esDigito(char c) {
    return c >= '0' && c <= '9';
}

bool Sistema::esEnteroValido(const string& texto) {
    int largo = (int)texto.length();
    int i = 0;
    if (largo > 0 && texto[0] == '-') i = 1;
    if (i == largo || largo - i > 9) return false;
    for (; i < largo; i++) {
        if (!esDigito(texto[i])) return false;
    }
    return true;
}

bool Sistema::esDecimalValido(const string& texto) {
    int largo = (int)texto.length();
    int i = 0;
    int digitos = 0;
    int puntos = 0;
    if (largo > 0 && texto[0] == '-') i = 1;
    for (; i < largo; i++) {
        if (esDigito(texto[i])) digitos++;
        else if (texto[i] == '.') puntos++;
        else return false;
    }
    return digitos > 0 && digitos <= 12 && puntos <= 1;
}

bool Sistema::esBisiesto(int anio) {
    return (anio % 4 == 0 && anio % 100 != 0) || anio % 400 == 0;
}

bool Sistema::fechaValida(const string& fecha) {
    if (fecha.length() != 10 || fecha[2] != '/' || fecha[5] != '/') return false;
    for (int i = 0; i < 10; i++) {
        if (i != 2 && i != 5 && !esDigito(fecha[i])) return false;
    }
    int dia = stoi(fecha.substr(0, 2));
    int mes = stoi(fecha.substr(3, 2));
    int anio = stoi(fecha.substr(6, 4));
    if (anio < 1900 || mes < 1 || mes > 12 || dia < 1) return false;
    int diasMes[] = { 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };
    int maximo = diasMes[mes - 1];
    if (mes == 2 && esBisiesto(anio)) maximo = 29;
    return dia <= maximo;
}

bool Sistema::horaValida(const string& hora) {
    if (hora.length() != 5 || hora[2] != ':') return false;
    if (!esDigito(hora[0]) || !esDigito(hora[1]) || !esDigito(hora[3]) || !esDigito(hora[4])) return false;
    int horas = stoi(hora.substr(0, 2));
    int minutos = stoi(hora.substr(3, 2));
    return horas <= 23 && minutos <= 59;
}

bool Sistema::correoValido(const string& correo) {
    int largo = (int)correo.length();
    int arrobas = 0;
    int posicionArroba = -1;
    for (int i = 0; i < largo; i++) {
        if (correo[i] == ' ') return false;
        if (correo[i] == '@') {
            arrobas++;
            posicionArroba = i;
        }
    }
    if (arrobas != 1 || posicionArroba == 0) return false;
    for (int i = posicionArroba + 2; i < largo - 1; i++) {
        if (correo[i] == '.') return true;
    }
    return false;
}

bool Sistema::telefonoValido(const string& telefono) {
    int digitos = 0;
    for (int i = 0; i < (int)telefono.length(); i++) {
        char c = telefono[i];
        if (esDigito(c)) digitos++;
        else if (c != '-' && c != ' ' && c != '+') return false;
    }
    return digitos >= 8 && digitos <= 15;
}

Sistema::Sistema() {
    datosPruebaCargados = false;
}

Sistema::~Sistema() {
    while (!centros.vacia()) {
        delete centros.extraerPrimero();
    }
}

void Sistema::iniciar() {
    menuPrincipal();
}

string Sistema::leerLinea(const string& mensaje) {
    string valor;
    cout << mensaje;
    if (!getline(cin, valor)) {
        cin.clear();
        return "";
    }
    return recortar(valor);
}

string Sistema::leerTexto(const string& mensaje) {
    while (true) {
        string valor = leerLinea(mensaje);
        if (!valor.empty()) return valor;
        cout << "Este dato es obligatorio y no puede quedar vacio." << endl;
    }
}

int Sistema::leerEntero(const string& mensaje) {
    while (true) {
        string texto = leerLinea(mensaje);
        if (esEnteroValido(texto)) return stoi(texto);
        cout << "Entrada invalida. Ingrese un numero entero." << endl;
    }
}

int Sistema::leerEnteroRango(const string& mensaje, int minimo, int maximo) {
    while (true) {
        int valor = leerEntero(mensaje);
        if (valor >= minimo && valor <= maximo) return valor;
        cout << "Valor fuera de rango. Debe estar entre " << minimo << " y " << maximo << "." << endl;
    }
}

double Sistema::leerDecimal(const string& mensaje) {
    while (true) {
        string texto = leerLinea(mensaje);
        if (esDecimalValido(texto)) return stod(texto);
        cout << "Entrada invalida. Ingrese un numero (use punto para decimales)." << endl;
    }
}

double Sistema::leerDecimalPositivo(const string& mensaje) {
    while (true) {
        double valor = leerDecimal(mensaje);
        if (valor > 0) return valor;
        cout << "El valor debe ser mayor que cero." << endl;
    }
}

double Sistema::leerDecimalRango(const string& mensaje, double minimo, double maximo) {
    while (true) {
        double valor = leerDecimal(mensaje);
        if (valor >= minimo && valor <= maximo) return valor;
        cout << "Valor fuera de rango. Debe estar entre " << minimo << " y " << maximo << "." << endl;
    }
}

string Sistema::leerFecha(const string& mensaje) {
    while (true) {
        string fecha = leerLinea(mensaje);
        if (fechaValida(fecha)) return fecha;
        cout << "Fecha invalida. Use el formato DD/MM/AAAA con una fecha existente." << endl;
    }
}

string Sistema::leerHora(const string& mensaje) {
    while (true) {
        string hora = leerLinea(mensaje);
        if (horaValida(hora)) return hora;
        cout << "Hora invalida. Use el formato HH:MM de 24 horas." << endl;
    }
}

string Sistema::leerCorreo(const string& mensaje) {
    while (true) {
        string correo = leerLinea(mensaje);
        if (correoValido(correo)) return correo;
        cout << "Correo invalido. Ejemplo: nombre@dominio.com" << endl;
    }
}

string Sistema::leerTelefono(const string& mensaje) {
    while (true) {
        string telefono = leerLinea(mensaje);
        if (telefonoValido(telefono)) return telefono;
        cout << "Telefono invalido. Debe contener al menos 8 digitos." << endl;
    }
}

bool Sistema::confirmar(const string& mensaje) {
    while (true) {
        string respuesta = leerLinea(mensaje + " (S/N): ");
        if (respuesta == "S" || respuesta == "s") return true;
        if (respuesta == "N" || respuesta == "n") return false;
        cout << "Responda S o N." << endl;
    }
}

void Sistema::pausa() {
    leerLinea("\nPresione ENTER para continuar...");
}

void Sistema::titulo(const string& texto) {
    cout << endl << "==============================================" << endl;
    cout << "  " << texto << endl;
    cout << "==============================================" << endl;
}

CentroDistribucion* Sistema::buscarCentroPorCodigo(const string& codigo) {
    for (Nodo<CentroDistribucion*>* n = centros.getPrimero(); n != nullptr; n = n->getSiguiente()) {
        if (n->getDato()->getCodigoUnico() == codigo) return n->getDato();
    }
    return nullptr;
}

Paquete* Sistema::buscarPaqueteGlobal(const string& codigo) {
    for (Nodo<CentroDistribucion*>* n = centros.getPrimero(); n != nullptr; n = n->getSiguiente()) {
        Paquete* paquete = n->getDato()->buscarPaquete(codigo);
        if (paquete != nullptr) return paquete;
    }
    return nullptr;
}

Solicitud* Sistema::buscarSolicitudGlobal(const string& codigo) {
    for (Nodo<CentroDistribucion*>* n = centros.getPrimero(); n != nullptr; n = n->getSiguiente()) {
        Solicitud* solicitud = n->getDato()->buscarSolicitud(codigo);
        if (solicitud != nullptr) return solicitud;
    }
    return nullptr;
}

Despacho* Sistema::buscarDespachoGlobal(const string& codigo) {
    for (Nodo<CentroDistribucion*>* n = centros.getPrimero(); n != nullptr; n = n->getSiguiente()) {
        Despacho* despacho = n->getDato()->buscarDespacho(codigo);
        if (despacho != nullptr) return despacho;
    }
    return nullptr;
}

CentroDistribucion* Sistema::seleccionarCentro() {
    if (centros.vacia()) {
        cout << "No hay centros de distribucion registrados." << endl;
        return nullptr;
    }
    cout << "Centros disponibles:" << endl;
    for (Nodo<CentroDistribucion*>* n = centros.getPrimero(); n != nullptr; n = n->getSiguiente()) {
        cout << "  " << n->getDato()->getCodigoUnico() << " - " << n->getDato()->getNombre() << endl;
    }
    CentroDistribucion* centro = buscarCentroPorCodigo(leerTexto("Codigo del centro: "));
    if (centro == nullptr) cout << "No existe un centro con ese codigo." << endl;
    return centro;
}

Cliente* Sistema::seleccionarCliente(CentroDistribucion* centro) {
    if (centro->getClientes().vacia()) {
        cout << "El centro no tiene clientes registrados." << endl;
        return nullptr;
    }
    cout << "Clientes del centro:" << endl;
    for (Nodo<Cliente*>* n = centro->getClientes().getPrimero(); n != nullptr; n = n->getSiguiente()) {
        cout << "  " << n->getDato()->getIdCliente() << " - " << n->getDato()->getNombre()
            << " (" << n->getDato()->getTipo() << ")" << endl;
    }
    Cliente* cliente = centro->buscarCliente(leerTexto("Identificacion del cliente: "));
    if (cliente == nullptr) cout << "El cliente no existe en este centro." << endl;
    return cliente;
}

Colaborador* Sistema::seleccionarColaborador(CentroDistribucion* centro) {
    if (centro->getColaboradores().vacia()) {
        cout << "El centro no tiene colaboradores registrados." << endl;
        return nullptr;
    }
    cout << "Colaboradores del centro:" << endl;
    for (Nodo<Colaborador*>* n = centro->getColaboradores().getPrimero(); n != nullptr; n = n->getSiguiente()) {
        cout << "  " << n->getDato()->getIdColaborador() << " - " << n->getDato()->getNombre()
            << " (" << n->getDato()->getPuesto() << ")" << endl;
    }
    Colaborador* colaborador = centro->buscarColaborador(leerTexto("Identificacion del colaborador responsable: "));
    if (colaborador == nullptr) cout << "El colaborador no existe en este centro." << endl;
    return colaborador;
}

Bodega* Sistema::seleccionarBodega(CentroDistribucion* centro) {
    if (centro->getBodegas().vacia()) {
        cout << "El centro no tiene bodegas registradas." << endl;
        return nullptr;
    }
    cout << "Bodegas del centro:" << endl;
    for (Nodo<Bodega*>* n = centro->getBodegas().getPrimero(); n != nullptr; n = n->getSiguiente()) {
        cout << "  " << n->getDato()->getCodigo() << " - " << n->getDato()->getNombre()
            << " (" << n->getDato()->getNombreTipo() << ")" << endl;
    }
    Bodega* bodega = centro->buscarBodega(leerTexto("Codigo de la bodega: "));
    if (bodega == nullptr) cout << "La bodega no existe en este centro." << endl;
    return bodega;
}

Paquete* Sistema::seleccionarPaquete() {
    Paquete* paquete = buscarPaqueteGlobal(leerTexto("Codigo unico del paquete: "));
    if (paquete == nullptr) cout << "No existe un paquete con ese codigo." << endl;
    return paquete;
}

Solicitud* Sistema::seleccionarSolicitud() {
    Solicitud* solicitud = buscarSolicitudGlobal(leerTexto("Codigo unico de la solicitud: "));
    if (solicitud == nullptr) cout << "No existe una solicitud con ese codigo." << endl;
    return solicitud;
}

Despacho* Sistema::seleccionarDespacho() {
    Despacho* despacho = buscarDespachoGlobal(leerTexto("Codigo unico del despacho: "));
    if (despacho == nullptr) cout << "No existe un despacho con ese codigo." << endl;
    return despacho;
}

bool Sistema::seleccionarCeldaDisponible(Bodega* bodega, int& fila, int& columna) {
    bodega->mostrarMatriz();
    fila = leerEnteroRango("Fila (0 a " + to_string(bodega->getFilas() - 1) + "): ", 0, bodega->getFilas() - 1);
    columna = leerEnteroRango("Columna (0 a " + to_string(bodega->getColumnas() - 1) + "): ", 0, bodega->getColumnas() - 1);
    if (!bodega->estaDisponible(fila, columna)) {
        cout << "La celda " << bodega->nombreCelda(fila, columna) << " no esta disponible." << endl;
        return false;
    }
    return true;
}

void Sistema::listarBodegasCompatibles(CentroDistribucion* centro, int categoria) {
    cout << "Bodegas compatibles con la categoria " << Categoria::nombre(categoria) << ":" << endl;
    bool hay = false;
    for (Nodo<Bodega*>* n = centro->getBodegas().getPrimero(); n != nullptr; n = n->getSiguiente()) {
        Bodega* bodega = n->getDato();
        if (bodega->esCompatible(categoria)) {
            cout << "  " << bodega->getCodigo() << " - " << bodega->getNombre()
                << " | Libres: " << bodega->contarLibres() << "/" << bodega->getTotalCeldas()
                << " | Disponible: " << fixed << setprecision(2) << bodega->porcentajeDisponible() << "%" << endl;
            hay = true;
        }
    }
    if (!hay) cout << "  (ninguna)" << endl;
}

void Sistema::menuPrincipal() {
    int opcion = -1;
    while (opcion != 0) {
        titulo("SISTEMA DE GESTION TicoPack Logistics");
        cout << "1. Centros de distribucion" << endl;
        cout << "2. Clientes" << endl;
        cout << "3. Colaboradores" << endl;
        cout << "4. Bodegas y consulta de matrices" << endl;
        cout << "5. Paquetes, almacenamiento, reubicacion y estados" << endl;
        cout << "6. Solicitudes de envio" << endl;
        cout << "7. Despachos" << endl;
        cout << "8. Reportes" << endl;
        cout << "9. Cargar datos de prueba" << endl;
        cout << "0. Salir del sistema" << endl;
        opcion = leerEntero("Seleccione una opcion: ");
        switch (opcion) {
            case 1: menuCentros(); break;
            case 2: menuClientes(); break;
            case 3: menuColaboradores(); break;
            case 4: menuBodegas(); break;
            case 5: menuPaquetes(); break;
            case 6: menuSolicitudes(); break;
            case 7: menuDespachos(); break;
            case 8: menuReportes(); break;
            case 9: cargarDatosPrueba(); pausa(); break;
            case 0: cout << "Saliendo del sistema..." << endl; break;
            default: cout << "Opcion invalida." << endl; pausa(); break;
        }
    }
}

void Sistema::menuCentros() {
    int opcion = -1;
    while (opcion != 0) {
        titulo("CENTROS DE DISTRIBUCION");
        cout << "1. Registrar centro" << endl;
        cout << "2. Buscar centro" << endl;
        cout << "3. Mostrar centros" << endl;
        cout << "4. Eliminar centro" << endl;
        cout << "0. Volver" << endl;
        opcion = leerEntero("Opcion: ");
        switch (opcion) {
            case 1: registrarCentro(); break;
            case 2: buscarCentro(); break;
            case 3: mostrarCentros(); break;
            case 4: eliminarCentro(); break;
            case 0: continue;
            default: cout << "Opcion invalida." << endl; break;
        }
        pausa();
    }
}

void Sistema::registrarCentro() {
    string codigo = leerTexto("Codigo unico del centro: ");
    if (buscarCentroPorCodigo(codigo) != nullptr) {
        cout << "Ya existe un centro con ese codigo." << endl;
        return;
    }
    string nombre = leerTexto("Nombre: ");
    string provincia = leerTexto("Provincia: ");
    string direccion = leerTexto("Direccion descriptiva: ");
    string telefono = leerTelefono("Telefono: ");
    centros.agregar(new CentroDistribucion(codigo, nombre, provincia, direccion, telefono));
    cout << "Centro registrado correctamente." << endl;
}

void Sistema::buscarCentro() {
    CentroDistribucion* centro = buscarCentroPorCodigo(leerTexto("Codigo del centro: "));
    if (centro == nullptr) {
        cout << "No existe un centro con ese codigo." << endl;
        return;
    }
    centro->mostrarDatos();
}

void Sistema::mostrarCentros() {
    if (centros.vacia()) {
        cout << "No hay centros registrados." << endl;
        return;
    }
    for (Nodo<CentroDistribucion*>* n = centros.getPrimero(); n != nullptr; n = n->getSiguiente()) {
        cout << "----------------------------------------------" << endl;
        n->getDato()->mostrarDatos();
    }
}

void Sistema::eliminarCentro() {
    CentroDistribucion* centro = buscarCentroPorCodigo(leerTexto("Codigo del centro a eliminar: "));
    if (centro == nullptr) {
        cout << "No existe un centro con ese codigo." << endl;
        return;
    }
    if (!centro->estaVacio()) {
        cout << "No se puede eliminar: el centro tiene clientes, colaboradores, bodegas, paquetes, solicitudes o despachos asociados." << endl;
        return;
    }
    if (!confirmar("Confirma la eliminacion del centro " + centro->getCodigoUnico())) {
        cout << "Operacion cancelada." << endl;
        return;
    }
    centros.eliminarDato(centro);
    delete centro;
    cout << "Centro eliminado." << endl;
}

void Sistema::menuClientes() {
    int opcion = -1;
    while (opcion != 0) {
        titulo("CLIENTES");
        cout << "1. Registrar cliente" << endl;
        cout << "2. Buscar cliente" << endl;
        cout << "3. Mostrar clientes de un centro" << endl;
        cout << "4. Eliminar cliente" << endl;
        cout << "0. Volver" << endl;
        opcion = leerEntero("Opcion: ");
        switch (opcion) {
            case 1: registrarCliente(); break;
            case 2: buscarCliente(); break;
            case 3: mostrarClientes(); break;
            case 4: eliminarCliente(); break;
            case 0: continue;
            default: cout << "Opcion invalida." << endl; break;
        }
        pausa();
    }
}

void Sistema::registrarCliente() {
    CentroDistribucion* centro = seleccionarCentro();
    if (centro == nullptr) return;
    string id = leerTexto("Identificacion: ");
    if (centro->buscarCliente(id) != nullptr) {
        cout << "Ya existe un cliente con esa identificacion en este centro." << endl;
        return;
    }
    cout << "Tipo de cliente:" << endl << "  1. Persona fisica" << endl << "  2. Empresa" << endl;
    int tipo = leerEnteroRango("Tipo: ", 1, 2);
    string nombre = leerTexto("Nombre: ");
    string telefono = leerTelefono("Telefono: ");
    string correo = leerCorreo("Correo electronico: ");
    Cliente* cliente = nullptr;
    if (tipo == 1) {
        cliente = new PersonaFisica(id, nombre, telefono, correo);
    } else {
        string actividad = leerTexto("Actividad economica: ");
        double descuento = leerDecimalRango("Porcentaje de descuento autorizado (0 a 100): ", 0, 100);
        cliente = new Empresa(id, nombre, telefono, correo, actividad, descuento);
    }
    centro->agregarCliente(cliente);
    cout << "Cliente registrado correctamente." << endl;
}

void Sistema::buscarCliente() {
    CentroDistribucion* centro = seleccionarCentro();
    if (centro == nullptr) return;
    Cliente* cliente = centro->buscarCliente(leerTexto("Identificacion del cliente: "));
    if (cliente == nullptr) {
        cout << "El cliente no existe en este centro." << endl;
        return;
    }
    cliente->mostrar();
}

void Sistema::mostrarClientes() {
    CentroDistribucion* centro = seleccionarCentro();
    if (centro == nullptr) return;
    if (centro->getClientes().vacia()) {
        cout << "No hay clientes registrados en este centro." << endl;
        return;
    }
    for (Nodo<Cliente*>* n = centro->getClientes().getPrimero(); n != nullptr; n = n->getSiguiente()) {
        cout << "----------------------------------------------" << endl;
        n->getDato()->mostrar();
    }
}

void Sistema::eliminarCliente() {
    CentroDistribucion* centro = seleccionarCentro();
    if (centro == nullptr) return;
    Cliente* cliente = seleccionarCliente(centro);
    if (cliente == nullptr) return;
    if (centro->clienteTieneDependencias(cliente)) {
        cout << "No se puede eliminar: el cliente tiene paquetes, solicitudes o despachos asociados." << endl;
        return;
    }
    if (!confirmar("Confirma la eliminacion del cliente " + cliente->getIdCliente())) {
        cout << "Operacion cancelada." << endl;
        return;
    }
    centro->eliminarCliente(cliente);
    cout << "Cliente eliminado." << endl;
}

void Sistema::menuColaboradores() {
    int opcion = -1;
    while (opcion != 0) {
        titulo("COLABORADORES");
        cout << "1. Registrar colaborador" << endl;
        cout << "2. Buscar colaborador" << endl;
        cout << "3. Mostrar colaboradores de un centro" << endl;
        cout << "4. Eliminar colaborador" << endl;
        cout << "0. Volver" << endl;
        opcion = leerEntero("Opcion: ");
        switch (opcion) {
            case 1: registrarColaborador(); break;
            case 2: buscarColaborador(); break;
            case 3: mostrarColaboradores(); break;
            case 4: eliminarColaborador(); break;
            case 0: continue;
            default: cout << "Opcion invalida." << endl; break;
        }
        pausa();
    }
}

void Sistema::registrarColaborador() {
    CentroDistribucion* centro = seleccionarCentro();
    if (centro == nullptr) return;
    string id = leerTexto("Identificacion: ");
    if (centro->buscarColaborador(id) != nullptr) {
        cout << "Ya existe un colaborador con esa identificacion en este centro." << endl;
        return;
    }
    string nombre = leerTexto("Nombre completo: ");
    string fecha = leerFecha("Fecha de ingreso (DD/MM/AAAA): ");
    string puesto = leerTexto("Puesto: ");
    centro->agregarColaborador(new Colaborador(id, nombre, fecha, puesto));
    cout << "Colaborador registrado correctamente." << endl;
}

void Sistema::buscarColaborador() {
    CentroDistribucion* centro = seleccionarCentro();
    if (centro == nullptr) return;
    Colaborador* colaborador = centro->buscarColaborador(leerTexto("Identificacion del colaborador: "));
    if (colaborador == nullptr) {
        cout << "El colaborador no existe en este centro." << endl;
        return;
    }
    colaborador->mostrarDatos();
}

void Sistema::mostrarColaboradores() {
    CentroDistribucion* centro = seleccionarCentro();
    if (centro == nullptr) return;
    if (centro->getColaboradores().vacia()) {
        cout << "No hay colaboradores registrados en este centro." << endl;
        return;
    }
    for (Nodo<Colaborador*>* n = centro->getColaboradores().getPrimero(); n != nullptr; n = n->getSiguiente()) {
        cout << "----------------------------------------------" << endl;
        n->getDato()->mostrarDatos();
    }
}

void Sistema::eliminarColaborador() {
    CentroDistribucion* centro = seleccionarCentro();
    if (centro == nullptr) return;
    Colaborador* colaborador = seleccionarColaborador(centro);
    if (colaborador == nullptr) return;
    if (centro->colaboradorTieneDependencias(colaborador)) {
        cout << "No se puede eliminar: el colaborador aparece como responsable en solicitudes, despachos o bitacoras." << endl;
        return;
    }
    if (!confirmar("Confirma la eliminacion del colaborador " + colaborador->getIdColaborador())) {
        cout << "Operacion cancelada." << endl;
        return;
    }
    centro->eliminarColaborador(colaborador);
    cout << "Colaborador eliminado." << endl;
}

void Sistema::menuBodegas() {
    int opcion = -1;
    while (opcion != 0) {
        titulo("BODEGAS Y CONSULTA DE MATRICES");
        cout << "1. Registrar bodega" << endl;
        cout << "2. Buscar bodega y consultar su matriz" << endl;
        cout << "3. Mostrar bodegas de un centro" << endl;
        cout << "4. Consultar celda (paquete almacenado)" << endl;
        cout << "5. Eliminar bodega" << endl;
        cout << "0. Volver" << endl;
        opcion = leerEntero("Opcion: ");
        switch (opcion) {
            case 1: registrarBodega(); break;
            case 2: buscarBodega(); break;
            case 3: mostrarBodegas(); break;
            case 4: consultarCelda(); break;
            case 5: eliminarBodega(); break;
            case 0: continue;
            default: cout << "Opcion invalida." << endl; break;
        }
        pausa();
    }
}

void Sistema::registrarBodega() {
    CentroDistribucion* centro = seleccionarCentro();
    if (centro == nullptr) return;
    string codigo = leerTexto("Codigo propio de la bodega: ");
    if (centro->buscarBodega(codigo) != nullptr) {
        cout << "Ya existe una bodega con ese codigo en este centro." << endl;
        return;
    }
    string nombre = leerTexto("Nombre: ");
    cout << "Tipos de bodega:" << endl;
    Categoria::mostrarOpciones();
    int tipo = leerEnteroRango("Codigo de tipo: ", Categoria::GENERAL, Categoria::DOCUMENTOS);
    int filas = leerEnteroRango("Cantidad de filas (mayor que 0): ", 1, 1000);
    int columnas = leerEnteroRango("Cantidad de columnas (mayor que 0): ", 1, 1000);
    Bodega* bodega = new Bodega(codigo, nombre, tipo, filas, columnas);
    if (!centro->agregarBodega(bodega)) {
        delete bodega;
        cout << "No se pudo registrar la bodega." << endl;
        return;
    }
    cout << "Bodega registrada con " << bodega->getTotalCeldas() << " celdas de almacenamiento." << endl;
}

void Sistema::buscarBodega() {
    CentroDistribucion* centro = seleccionarCentro();
    if (centro == nullptr) return;
    Bodega* bodega = centro->buscarBodega(leerTexto("Codigo de la bodega: "));
    if (bodega == nullptr) {
        cout << "La bodega no existe en este centro." << endl;
        return;
    }
    bodega->mostrarDatos();
    bodega->mostrarMatriz();
}

void Sistema::mostrarBodegas() {
    CentroDistribucion* centro = seleccionarCentro();
    if (centro == nullptr) return;
    if (centro->getBodegas().vacia()) {
        cout << "El centro aun no tiene bodegas registradas." << endl;
        return;
    }
    for (Nodo<Bodega*>* n = centro->getBodegas().getPrimero(); n != nullptr; n = n->getSiguiente()) {
        cout << "----------------------------------------------" << endl;
        n->getDato()->mostrarDatos();
        n->getDato()->mostrarMatriz();
    }
}

void Sistema::consultarCelda() {
    CentroDistribucion* centro = seleccionarCentro();
    if (centro == nullptr) return;
    Bodega* bodega = seleccionarBodega(centro);
    if (bodega == nullptr) return;
    bodega->mostrarMatriz();
    int fila = leerEnteroRango("Fila (0 a " + to_string(bodega->getFilas() - 1) + "): ", 0, bodega->getFilas() - 1);
    int columna = leerEnteroRango("Columna (0 a " + to_string(bodega->getColumnas() - 1) + "): ", 0, bodega->getColumnas() - 1);
    cout << "Celda " << bodega->nombreCelda(fila, columna) << ": ";
    Paquete* paquete = bodega->getPaquete(fila, columna);
    if (paquete == nullptr) {
        cout << "LIBRE" << endl;
        return;
    }
    cout << "OCUPADA" << endl << "Paquete almacenado:" << endl;
    paquete->mostrarDatos();
}

void Sistema::eliminarBodega() {
    CentroDistribucion* centro = seleccionarCentro();
    if (centro == nullptr) return;
    Bodega* bodega = seleccionarBodega(centro);
    if (bodega == nullptr) return;
    if (centro->bodegaTienePaquetes(bodega)) {
        cout << "No se puede eliminar: la bodega tiene celdas ocupadas o paquetes asignados." << endl;
        return;
    }
    if (!confirmar("Confirma la eliminacion de la bodega " + bodega->getCodigo())) {
        cout << "Operacion cancelada." << endl;
        return;
    }
    centro->eliminarBodega(bodega);
    cout << "Bodega eliminada y memoria de la matriz liberada." << endl;
}

void Sistema::menuPaquetes() {
    int opcion = -1;
    while (opcion != 0) {
        titulo("PAQUETES, ALMACENAMIENTO, REUBICACION Y ESTADOS");
        cout << "1. Registrar paquete" << endl;
        cout << "2. Buscar paquete" << endl;
        cout << "3. Mostrar paquetes de un centro" << endl;
        cout << "4. Almacenar paquete (asignar celda)" << endl;
        cout << "5. Reubicar paquete" << endl;
        cout << "6. Registrar incidencia" << endl;
        cout << "7. Resolver incidencia" << endl;
        cout << "8. Eliminar paquete" << endl;
        cout << "0. Volver" << endl;
        opcion = leerEntero("Opcion: ");
        switch (opcion) {
            case 1: registrarPaquete(); break;
            case 2: buscarPaquete(); break;
            case 3: mostrarPaquetes(); break;
            case 4: {
                Paquete* paquete = seleccionarPaquete();
                if (paquete != nullptr) almacenarPaquete(paquete);
                break;
            }
            case 5: reubicarPaquete(); break;
            case 6: registrarIncidencia(); break;
            case 7: resolverIncidencia(); break;
            case 8: eliminarPaquete(); break;
            case 0: continue;
            default: cout << "Opcion invalida." << endl; break;
        }
        pausa();
    }
}

void Sistema::registrarPaquete() {
    CentroDistribucion* centro = seleccionarCentro();
    if (centro == nullptr) return;
    if (centro->getClientes().vacia()) {
        cout << "Debe registrar al menos un cliente en este centro antes de registrar paquetes." << endl;
        return;
    }
    string codigo = leerTexto("Codigo unico del paquete: ");
    if (buscarPaqueteGlobal(codigo) != nullptr) {
        cout << "Ya existe un paquete con ese codigo en el sistema." << endl;
        return;
    }
    string descripcion = leerTexto("Descripcion: ");
    double peso = leerDecimalPositivo("Peso en kilogramos (mayor que 0): ");
    cout << "Categorias:" << endl;
    Categoria::mostrarOpciones();
    int categoria = leerEnteroRango("Categoria: ", Categoria::GENERAL, Categoria::DOCUMENTOS);
    Cliente* cliente = seleccionarCliente(centro);
    if (cliente == nullptr) return;
    Paquete* paquete = new Paquete(codigo, descripcion, peso, categoria, cliente, centro);
    if (!centro->agregarPaquete(paquete)) {
        delete paquete;
        cout << "No se pudo registrar el paquete." << endl;
        return;
    }
    cout << "Paquete registrado en estado " << Paquete::RECIBIDO << " y sin ubicacion asignada." << endl;
}

void Sistema::buscarPaquete() {
    Paquete* paquete = seleccionarPaquete();
    if (paquete != nullptr) paquete->mostrarDatos();
}

void Sistema::mostrarPaquetes() {
    CentroDistribucion* centro = seleccionarCentro();
    if (centro == nullptr) return;
    if (centro->getPaquetes().vacia()) {
        cout << "No hay paquetes registrados en este centro." << endl;
        return;
    }
    for (Nodo<Paquete*>* n = centro->getPaquetes().getPrimero(); n != nullptr; n = n->getSiguiente()) {
        cout << "----------------------------------------------" << endl;
        n->getDato()->mostrarDatos();
    }
}

void Sistema::almacenarPaquete(Paquete* paquete) {
    if (!paquete->requiereAlmacenamiento()) {
        if (paquete->getEstadoActual() == Paquete::INCIDENCIA && paquete->tieneUbicacion()) {
            cout << "El paquete conserva su celda; use la opcion Resolver incidencia." << endl;
        } else if (paquete->getEstadoActual() == Paquete::INCIDENCIA) {
            cout << "El paquete pertenece a un despacho En proceso; use la opcion Resolver incidencia." << endl;
        } else {
            cout << "Solo se puede almacenar un paquete Recibido o una Incidencia sin ubicacion previa al despacho." << endl;
        }
        return;
    }
    CentroDistribucion* centro = paquete->getCentro();
    Bodega* recomendada = centro->recomendarBodega(paquete->getCategoria());
    if (recomendada == nullptr) {
        cout << "No existe una bodega compatible (" << paquete->getNombreCategoria()
            << ") con espacio disponible. El paquete conserva su estado y ubicacion." << endl;
        return;
    }
    int fila = -1;
    int columna = -1;
    recomendada->primeraCeldaLibre(fila, columna);
    listarBodegasCompatibles(centro, paquete->getCategoria());
    recomendada->mostrarMatriz();
    cout << "Recomendacion: bodega " << recomendada->getCodigo() << " (mayor espacio disponible: "
        << fixed << setprecision(2) << recomendada->porcentajeDisponible() << "%), celda "
        << recomendada->nombreCelda(fila, columna) << endl;
    Bodega* elegida = recomendada;
    if (!confirmar("Desea aceptar la celda recomendada")) {
        elegida = centro->buscarBodega(leerTexto("Codigo de la bodega compatible: "));
        if (elegida == nullptr || !elegida->esCompatible(paquete->getCategoria())) {
            cout << "La bodega no existe en este centro o no es compatible con la categoria del paquete." << endl;
            return;
        }
        if (!seleccionarCeldaDisponible(elegida, fila, columna)) return;
    }
    Colaborador* colaborador = seleccionarColaborador(centro);
    if (colaborador == nullptr) return;
    string fecha = leerFecha("Fecha del cambio (DD/MM/AAAA): ");
    if (paquete->almacenar(elegida, fila, columna, colaborador, fecha)) {
        cout << "Paquete almacenado en la celda " << paquete->getUbicacion() << ". Estado: " << paquete->getEstadoActual() << endl;
    } else {
        cout << "No se pudo almacenar el paquete. No se modifico su estado ni su ubicacion." << endl;
    }
}

void Sistema::reubicarPaquete() {
    Paquete* paquete = seleccionarPaquete();
    if (paquete == nullptr) return;
    if (paquete->getEstadoActual() != Paquete::ALMACENADO || !paquete->tieneUbicacion()) {
        cout << "Solo se puede reubicar un paquete en estado Almacenado." << endl;
        return;
    }
    CentroDistribucion* centro = paquete->getCentro();
    cout << "Ubicacion actual: " << paquete->getUbicacion() << endl;
    listarBodegasCompatibles(centro, paquete->getCategoria());
    Bodega* destino = centro->buscarBodega(leerTexto("Codigo de la bodega destino: "));
    if (destino == nullptr || !destino->esCompatible(paquete->getCategoria())) {
        cout << "La bodega no existe en este centro o no es compatible. La ubicacion original se conserva." << endl;
        return;
    }
    int fila = -1;
    int columna = -1;
    if (!seleccionarCeldaDisponible(destino, fila, columna)) {
        cout << "La ubicacion original se conserva." << endl;
        return;
    }
    string anterior = paquete->getUbicacion();
    if (paquete->reubicar(destino, fila, columna)) {
        cout << "Paquete reubicado de " << anterior << " a " << paquete->getUbicacion() << "." << endl;
    } else {
        cout << "No se pudo reubicar. La ubicacion original se conserva." << endl;
    }
}

void Sistema::registrarIncidencia() {
    Paquete* paquete = seleccionarPaquete();
    if (paquete == nullptr) return;
    string estado = paquete->getEstadoActual();
    if (estado != Paquete::RECIBIDO && estado != Paquete::ALMACENADO && estado != Paquete::EN_TRANSITO) {
        cout << "No se puede registrar una incidencia desde el estado " << estado << "." << endl;
        return;
    }
    Colaborador* colaborador = seleccionarColaborador(paquete->getCentro());
    if (colaborador == nullptr) return;
    string fecha = leerFecha("Fecha del cambio (DD/MM/AAAA): ");
    if (paquete->registrarIncidencia(colaborador, fecha)) {
        cout << "Incidencia registrada. Ubicacion: " << paquete->getUbicacion() << endl;
    } else {
        cout << "No se pudo registrar la incidencia." << endl;
    }
}

void Sistema::resolverIncidencia() {
    Paquete* paquete = seleccionarPaquete();
    if (paquete == nullptr) return;
    if (paquete->getEstadoActual() != Paquete::INCIDENCIA) {
        cout << "El paquete no se encuentra en estado Incidencia." << endl;
        return;
    }
    if (paquete->requiereAlmacenamiento()) {
        cout << "El paquete no tiene celda ni despacho activo; para resolver la incidencia debe almacenarse." << endl;
        if (confirmar("Desea almacenarlo ahora")) almacenarPaquete(paquete);
        return;
    }
    Colaborador* colaborador = seleccionarColaborador(paquete->getCentro());
    if (colaborador == nullptr) return;
    string fecha = leerFecha("Fecha del cambio (DD/MM/AAAA): ");
    if (paquete->resolverIncidencia(colaborador, fecha)) {
        cout << "Incidencia resuelta. Nuevo estado: " << paquete->getEstadoActual() << endl;
    } else {
        cout << "No se pudo resolver la incidencia." << endl;
    }
}

void Sistema::eliminarPaquete() {
    Paquete* paquete = seleccionarPaquete();
    if (paquete == nullptr) return;
    CentroDistribucion* centro = paquete->getCentro();
    if (paquete->getEstadoActual() != Paquete::RECIBIDO || paquete->tieneUbicacion() || centro->paqueteTieneDependencias(paquete)) {
        cout << "No se puede eliminar: el paquete debe estar Recibido, sin celda asignada y sin solicitudes ni despachos." << endl;
        return;
    }
    if (!confirmar("Confirma la eliminacion del paquete " + paquete->getCodigoUnico())) {
        cout << "Operacion cancelada." << endl;
        return;
    }
    centro->eliminarPaquete(paquete);
    cout << "Paquete eliminado." << endl;
}

void Sistema::menuSolicitudes() {
    int opcion = -1;
    while (opcion != 0) {
        titulo("SOLICITUDES DE ENVIO");
        cout << "1. Crear solicitud" << endl;
        cout << "2. Buscar solicitud" << endl;
        cout << "3. Mostrar solicitudes de un centro" << endl;
        cout << "4. Aprobar solicitud (genera el despacho)" << endl;
        cout << "5. Rechazar solicitud" << endl;
        cout << "6. Anular solicitud" << endl;
        cout << "0. Volver" << endl;
        opcion = leerEntero("Opcion: ");
        switch (opcion) {
            case 1: crearSolicitud(); break;
            case 2: buscarSolicitud(); break;
            case 3: mostrarSolicitudes(); break;
            case 4: aprobarSolicitud(); break;
            case 5: rechazarOAnularSolicitud(true); break;
            case 6: rechazarOAnularSolicitud(false); break;
            case 0: continue;
            default: cout << "Opcion invalida." << endl; break;
        }
        pausa();
    }
}

void Sistema::crearSolicitud() {
    CentroDistribucion* centro = seleccionarCentro();
    if (centro == nullptr) return;
    Paquete* paquete = centro->buscarPaquete(leerTexto("Codigo del paquete: "));
    if (paquete == nullptr) {
        cout << "El paquete no esta registrado en este centro." << endl;
        return;
    }
    if (paquete->getEstadoActual() != Paquete::ALMACENADO) {
        cout << "Solo se puede crear una solicitud para un paquete en estado Almacenado." << endl;
        return;
    }
    if (centro->tieneSolicitudPendiente(paquete)) {
        cout << "El paquete ya tiene una solicitud Pendiente." << endl;
        return;
    }
    if (centro->tieneSolicitudAprobada(paquete) || paquete->getDespacho() != nullptr) {
        cout << "El paquete ya tiene una solicitud Aprobada y un despacho asociado." << endl;
        return;
    }
    cout << "Cliente propietario: " << paquete->getCliente()->getNombre() << " (" << paquete->getCliente()->getIdCliente() << ")" << endl;
    Colaborador* colaborador = seleccionarColaborador(centro);
    if (colaborador == nullptr) return;
    string codigo = leerTexto("Codigo unico de la solicitud: ");
    if (buscarSolicitudGlobal(codigo) != nullptr) {
        cout << "Ya existe una solicitud con ese codigo en el sistema." << endl;
        return;
    }
    string destino = leerTexto("Destino de entrega (direccion): ");
    string fecha = leerFecha("Fecha de solicitud (DD/MM/AAAA): ");
    string error;
    Solicitud* solicitud = centro->crearSolicitud(codigo, paquete, colaborador, destino, fecha, error);
    if (solicitud == nullptr) {
        cout << error << endl;
        return;
    }
    cout << "Solicitud creada en estado " << solicitud->getEstado() << "." << endl;
    cout << "Costo estimado: " << fixed << setprecision(2) << solicitud->getCostoEstimado() << " colones" << endl;
}

void Sistema::buscarSolicitud() {
    Solicitud* solicitud = seleccionarSolicitud();
    if (solicitud != nullptr) solicitud->mostrarDatos();
}

void Sistema::mostrarSolicitudes() {
    CentroDistribucion* centro = seleccionarCentro();
    if (centro == nullptr) return;
    if (centro->getSolicitudes().vacia()) {
        cout << "No hay solicitudes registradas en este centro." << endl;
        return;
    }
    for (Nodo<Solicitud*>* n = centro->getSolicitudes().getPrimero(); n != nullptr; n = n->getSiguiente()) {
        cout << "----------------------------------------------" << endl;
        n->getDato()->mostrarDatos();
    }
}

void Sistema::aprobarSolicitud() {
    Solicitud* solicitud = seleccionarSolicitud();
    if (solicitud == nullptr) return;
    CentroDistribucion* centro = solicitud->getCentroOrigen();
    string error = centro->validarAprobacion(solicitud);
    if (!error.empty()) {
        cout << error << endl;
        return;
    }
    string codigo = leerTexto("Codigo unico del despacho: ");
    if (buscarDespachoGlobal(codigo) != nullptr) {
        cout << "Ya existe un despacho con ese codigo en el sistema." << endl;
        return;
    }
    string fecha = leerFecha("Fecha de despacho (DD/MM/AAAA): ");
    string hora = leerHora("Hora de despacho (HH:MM): ");
    Despacho* despacho = centro->aprobarSolicitud(solicitud, codigo, fecha, hora, error);
    if (despacho == nullptr) {
        cout << error << endl;
        return;
    }
    cout << "Solicitud aprobada. Despacho " << despacho->getCodigo() << " creado en estado " << despacho->getEstado() << "." << endl;
    cout << "El paquete " << despacho->getPaquete()->getCodigoUnico() << " paso a "
        << despacho->getPaquete()->getEstadoActual() << " y libero su celda." << endl;
}

void Sistema::rechazarOAnularSolicitud(bool rechazar) {
    Solicitud* solicitud = seleccionarSolicitud();
    if (solicitud == nullptr) return;
    if (solicitud->getEstado() != Solicitud::PENDIENTE) {
        cout << "La solicitud esta " << solicitud->getEstado() << "; solo se pueden modificar solicitudes Pendientes." << endl;
        return;
    }
    bool cambiado = rechazar ? solicitud->rechazar() : solicitud->anular();
    if (cambiado) cout << "Solicitud " << solicitud->getCodigo() << " actualizada a " << solicitud->getEstado() << "." << endl;
    else cout << "No se pudo actualizar la solicitud." << endl;
}

void Sistema::menuDespachos() {
    int opcion = -1;
    while (opcion != 0) {
        titulo("DESPACHOS");
        cout << "1. Buscar despacho" << endl;
        cout << "2. Mostrar despachos de un centro" << endl;
        cout << "3. Finalizar entrega" << endl;
        cout << "0. Volver" << endl;
        opcion = leerEntero("Opcion: ");
        switch (opcion) {
            case 1: buscarDespacho(); break;
            case 2: mostrarDespachos(); break;
            case 3: finalizarDespacho(); break;
            case 0: continue;
            default: cout << "Opcion invalida." << endl; break;
        }
        pausa();
    }
}

void Sistema::buscarDespacho() {
    Despacho* despacho = seleccionarDespacho();
    if (despacho != nullptr) despacho->mostrarDatos();
}

void Sistema::mostrarDespachos() {
    CentroDistribucion* centro = seleccionarCentro();
    if (centro == nullptr) return;
    if (centro->getDespachos().vacia()) {
        cout << "No hay despachos registrados en este centro." << endl;
        return;
    }
    for (Nodo<Despacho*>* n = centro->getDespachos().getPrimero(); n != nullptr; n = n->getSiguiente()) {
        cout << "----------------------------------------------" << endl;
        n->getDato()->mostrarDatos();
    }
}

void Sistema::finalizarDespacho() {
    Despacho* despacho = seleccionarDespacho();
    if (despacho == nullptr) return;
    if (despacho->getEstado() != Despacho::EN_PROCESO) {
        cout << "El despacho ya se encuentra " << despacho->getEstado() << "." << endl;
        return;
    }
    if (!despacho->puedeFinalizar()) {
        cout << "No se puede finalizar: el paquete esta en estado " << despacho->getPaquete()->getEstadoActual()
            << " y debe estar En transito." << endl;
        return;
    }
    string fecha = leerFecha("Fecha de entrega (DD/MM/AAAA): ");
    if (despacho->finalizar(fecha)) {
        cout << "Entrega finalizada. Despacho: " << despacho->getEstado()
            << " | Paquete: " << despacho->getPaquete()->getEstadoActual() << endl;
    } else {
        cout << "No se pudo finalizar la entrega." << endl;
    }
}

void Sistema::menuReportes() {
    int opcion = -1;
    while (opcion != 0) {
        titulo("REPORTES");
        cout << "1. Historial de un cliente" << endl;
        cout << "2. Clientes por cantidad de envios" << endl;
        cout << "3. Bitacora de un paquete" << endl;
        cout << "4. Consulta de despacho de un paquete" << endl;
        cout << "5. Ocupacion de bodegas" << endl;
        cout << "6. Despachos por colaborador" << endl;
        cout << "0. Volver" << endl;
        opcion = leerEntero("Opcion: ");
        switch (opcion) {
            case 1: reporteHistorialCliente(); break;
            case 2: reporteClientesPorEnvios(); break;
            case 3: reporteBitacoraPaquete(); break;
            case 4: reporteDespachoPaquete(); break;
            case 5: reporteOcupacionBodegas(); break;
            case 6: reporteDespachosPorColaborador(); break;
            case 0: continue;
            default: cout << "Opcion invalida." << endl; break;
        }
        pausa();
    }
}

void Sistema::reporteHistorialCliente() {
    CentroDistribucion* centro = seleccionarCentro();
    if (centro == nullptr) return;
    Cliente* cliente = seleccionarCliente(centro);
    if (cliente == nullptr) return;
    titulo("HISTORIAL DE " + cliente->getNombre());
    cout << "Solicitudes:" << endl;
    bool haySolicitudes = false;
    for (Nodo<Solicitud*>* n = centro->getSolicitudes().getPrimero(); n != nullptr; n = n->getSiguiente()) {
        if (n->getDato()->getCliente() == cliente) {
            cout << "  ";
            n->getDato()->mostrarResumen();
            haySolicitudes = true;
        }
    }
    if (!haySolicitudes) cout << "  El cliente no tiene solicitudes." << endl;
    cout << "Despachos:" << endl;
    bool hayDespachos = false;
    for (Nodo<Despacho*>* n = centro->getDespachos().getPrimero(); n != nullptr; n = n->getSiguiente()) {
        if (n->getDato()->getCliente() == cliente) {
            cout << "  ";
            n->getDato()->mostrarResumen();
            hayDespachos = true;
        }
    }
    if (!hayDespachos) cout << "  El cliente no tiene despachos." << endl;
}

void Sistema::reporteClientesPorEnvios() {
    CentroDistribucion* centro = seleccionarCentro();
    if (centro == nullptr) return;
    int cantidadClientes = centro->getClientes().size();
    if (cantidadClientes == 0) {
        cout << "El centro no tiene clientes registrados." << endl;
        return;
    }
    Cliente** ordenados = new Cliente*[cantidadClientes];
    int* envios = new int[cantidadClientes];
    int indice = 0;
    for (Nodo<Cliente*>* n = centro->getClientes().getPrimero(); n != nullptr; n = n->getSiguiente()) {
        ordenados[indice] = n->getDato();
        envios[indice] = centro->contarDespachosFinalizados(n->getDato());
        indice++;
    }
    for (int i = 1; i < cantidadClientes; i++) {
        Cliente* clienteActual = ordenados[i];
        int enviosActual = envios[i];
        int j = i - 1;
        while (j >= 0 && envios[j] < enviosActual) {
            ordenados[j + 1] = ordenados[j];
            envios[j + 1] = envios[j];
            j--;
        }
        ordenados[j + 1] = clienteActual;
        envios[j + 1] = enviosActual;
    }
    titulo("CLIENTES POR DESPACHOS FINALIZADOS - " + centro->getNombre());
    for (int i = 0; i < cantidadClientes; i++) {
        cout << i + 1 << ". " << ordenados[i]->getNombre() << " (" << ordenados[i]->getIdCliente() << ")"
            << " - Despachos finalizados: " << envios[i] << endl;
    }
    delete[] ordenados;
    delete[] envios;
}

void Sistema::reporteBitacoraPaquete() {
    Paquete* paquete = seleccionarPaquete();
    if (paquete != nullptr) paquete->mostrarBitacora();
}

void Sistema::reporteDespachoPaquete() {
    Paquete* paquete = seleccionarPaquete();
    if (paquete == nullptr) return;
    CentroDistribucion* centro = paquete->getCentro();
    Solicitud* aprobada = nullptr;
    for (Nodo<Solicitud*>* n = centro->getSolicitudes().getPrimero(); n != nullptr; n = n->getSiguiente()) {
        if (n->getDato()->getPaquete() == paquete && n->getDato()->getEstado() == Solicitud::APROBADA) aprobada = n->getDato();
    }
    Despacho* despacho = paquete->getDespacho();
    if (aprobada == nullptr && despacho == nullptr) {
        cout << "El paquete " << paquete->getCodigoUnico() << " no posee solicitud aprobada ni despacho." << endl;
        return;
    }
    if (aprobada != nullptr) {
        titulo("SOLICITUD APROBADA");
        aprobada->mostrarDatos();
    }
    if (despacho != nullptr) {
        titulo("DESPACHO ASOCIADO");
        despacho->mostrarDatos();
    } else {
        cout << "El paquete no posee despacho." << endl;
    }
}

void Sistema::reporteOcupacionBodegas() {
    if (centros.vacia()) {
        cout << "No hay centros registrados." << endl;
        return;
    }
    string codigo = leerLinea("Codigo del centro (ENTER para todos): ");
    CentroDistribucion* soloCentro = nullptr;
    if (!codigo.empty()) {
        soloCentro = buscarCentroPorCodigo(codigo);
        if (soloCentro == nullptr) {
            cout << "No existe un centro con ese codigo." << endl;
            return;
        }
    }
    for (Nodo<CentroDistribucion*>* n = centros.getPrimero(); n != nullptr; n = n->getSiguiente()) {
        CentroDistribucion* centro = n->getDato();
        if (soloCentro != nullptr && centro != soloCentro) continue;
        titulo("Centro " + centro->getCodigoUnico() + " - " + centro->getNombre());
        if (centro->getBodegas().vacia()) {
            cout << "  Sin bodegas registradas." << endl;
            continue;
        }
        int total = 0;
        int ocupadas = 0;
        for (Nodo<Bodega*>* b = centro->getBodegas().getPrimero(); b != nullptr; b = b->getSiguiente()) {
            cout << "  ";
            b->getDato()->mostrarOcupacion();
            total += b->getDato()->getTotalCeldas();
            ocupadas += b->getDato()->contarOcupadas();
        }
        cout << "  Total del centro | Celdas: " << total << " | Ocupadas: " << ocupadas
            << " | Disponibles: " << total - ocupadas << " | Ocupacion: " << fixed << setprecision(2)
             << (total > 0 ? (double)ocupadas / total * 100.0 : 0.0) << "%" << endl;
    }
}

void Sistema::reporteDespachosPorColaborador() {
    CentroDistribucion* centro = seleccionarCentro();
    if (centro == nullptr) return;
    Colaborador* colaborador = seleccionarColaborador(centro);
    if (colaborador == nullptr) return;
    titulo("DESPACHOS GESTIONADOS POR " + colaborador->getNombre());
    bool hay = false;
    for (Nodo<Despacho*>* n = centro->getDespachos().getPrimero(); n != nullptr; n = n->getSiguiente()) {
        if (n->getDato()->getColaborador() == colaborador) {
            n->getDato()->mostrarResumen();
            hay = true;
        }
    }
    if (!hay) cout << "El colaborador no ha gestionado despachos." << endl;
}

void Sistema::cargarDatosPrueba() {
    if (datosPruebaCargados) {
        cout << "Los datos de prueba ya fueron cargados." << endl;
        return;
    }
    if (buscarCentroPorCodigo("C01") != nullptr || buscarCentroPorCodigo("C02") != nullptr) {
        cout << "No se pueden cargar los datos de prueba: ya existen centros con los codigos C01 o C02." << endl;
        return;
    }
    const string codigosPaquete[] = { "PK101", "PK102", "PK103", "PK104", "PK105", "PK106", "PK201" };
    for (int i = 0; i < 7; i++) {
        if (buscarPaqueteGlobal(codigosPaquete[i]) != nullptr) {
            cout << "No se pueden cargar los datos de prueba: el codigo " << codigosPaquete[i] << " ya existe." << endl;
            return;
        }
    }
    const string codigosSolicitud[] = { "S001", "S002", "S003", "S004" };
    for (int i = 0; i < 4; i++) {
        if (buscarSolicitudGlobal(codigosSolicitud[i]) != nullptr) {
            cout << "No se pueden cargar los datos de prueba: el codigo " << codigosSolicitud[i] << " ya existe." << endl;
            return;
        }
    }
    if (buscarDespachoGlobal("D001") != nullptr || buscarDespachoGlobal("D002") != nullptr) {
        cout << "No se pueden cargar los datos de prueba: los codigos D001 o D002 ya existen." << endl;
        return;
    }

    CentroDistribucion* guapiles = new CentroDistribucion("C01", "Centro Guapiles", "Limon", "200 m norte del parque de Guapiles", "2710-1000");
    CentroDistribucion* heredia = new CentroDistribucion("C02", "Centro Heredia", "Heredia", "Zona industrial de Barreal", "2260-2000");
    centros.agregar(guapiles);
    centros.agregar(heredia);

    PersonaFisica* ana = new PersonaFisica("1-1111-1111", "Ana Mora Solis", "8888-1111", "ana@correo.com");
    Empresa* tecno = new Empresa("3-101-123456", "TecnoCR S.A.", "2222-3333", "ventas@tecnocr.com", "Venta de equipo de computo", 10);
    PersonaFisica* luis = new PersonaFisica("2-2222-2222", "Luis Vargas Rojas", "8777-2222", "luis@correo.com");
    guapiles->agregarCliente(ana);
    guapiles->agregarCliente(tecno);
    guapiles->agregarCliente(luis);
    Empresa* libreria = new Empresa("3-101-654321", "Libreria Central", "2261-4444", "info@libreria.com", "Venta de libros", 5);
    heredia->agregarCliente(libreria);

    Colaborador* carlos = new Colaborador("COL1", "Carlos Jimenez Arias", "15/01/2024", "Encargado de bodega");
    Colaborador* maria = new Colaborador("COL2", "Maria Fernandez Castro", "01/03/2025", "Despachadora");
    guapiles->agregarColaborador(carlos);
    guapiles->agregarColaborador(maria);
    Colaborador* jose = new Colaborador("COL3", "Jose Ramirez Quesada", "10/06/2023", "Operador");
    heredia->agregarColaborador(jose);

    Bodega* general = new Bodega("A", "Bodega General", Categoria::GENERAL, 5, 6);
    Bodega* fragil = new Bodega("F", "Bodega Fragil", Categoria::FRAGIL, 3, 4);
    Bodega* tecnologia = new Bodega("T", "Bodega Tecnologia", Categoria::TECNOLOGIA, 3, 3);
    Bodega* documentos = new Bodega("D", "Bodega Documentos", Categoria::DOCUMENTOS, 2, 5);
    guapiles->agregarBodega(general);
    guapiles->agregarBodega(fragil);
    guapiles->agregarBodega(tecnologia);
    guapiles->agregarBodega(documentos);
    Bodega* generalHeredia = new Bodega("H1", "Bodega Principal Heredia", Categoria::GENERAL, 4, 4);
    heredia->agregarBodega(generalHeredia);

    Paquete* p1 = new Paquete("PK101", "Caja de ropa", 3.5, Categoria::GENERAL, ana, guapiles);
    Paquete* p2 = new Paquete("PK102", "Computadora portatil", 2.2, Categoria::TECNOLOGIA, tecno, guapiles);
    Paquete* p3 = new Paquete("PK103", "Juego de copas", 4.0, Categoria::FRAGIL, luis, guapiles);
    Paquete* p4 = new Paquete("PK104", "Contratos firmados", 0.5, Categoria::DOCUMENTOS, tecno, guapiles);
    Paquete* p5 = new Paquete("PK105", "Monitor 27 pulgadas", 6.0, Categoria::TECNOLOGIA, tecno, guapiles);
    Paquete* p6 = new Paquete("PK106", "Zapatos", 1.8, Categoria::GENERAL, ana, guapiles);
    Paquete* p7 = new Paquete("PK201", "Libros de texto", 8.0, Categoria::GENERAL, libreria, heredia);
    guapiles->agregarPaquete(p1);
    guapiles->agregarPaquete(p2);
    guapiles->agregarPaquete(p3);
    guapiles->agregarPaquete(p4);
    guapiles->agregarPaquete(p5);
    guapiles->agregarPaquete(p6);
    heredia->agregarPaquete(p7);

    p1->almacenar(general, 0, 1, carlos, "20/10/2026");
    p2->almacenar(tecnologia, 1, 1, carlos, "20/10/2026");
    p3->almacenar(fragil, 2, 2, carlos, "21/10/2026");
    p4->almacenar(documentos, 0, 0, carlos, "21/10/2026");
    p5->almacenar(tecnologia, 0, 2, carlos, "22/10/2026");
    p7->almacenar(generalHeredia, 1, 3, jose, "22/10/2026");

    string error;
    Solicitud* s1 = guapiles->crearSolicitud("S001", p2, maria, "San Jose, Barrio Escalante", "23/10/2026", error);
    guapiles->aprobarSolicitud(s1, "D001", "24/10/2026", "08:30", error);
    guapiles->buscarDespacho("D001")->finalizar("25/10/2026");

    Solicitud* s2 = guapiles->crearSolicitud("S002", p5, maria, "Cartago centro", "24/10/2026", error);
    guapiles->aprobarSolicitud(s2, "D002", "25/10/2026", "10:15", error);
    p5->registrarIncidencia(maria, "26/10/2026");

    Solicitud* s3 = guapiles->crearSolicitud("S003", p1, carlos, "Limon centro", "25/10/2026", error);
    s3->rechazar();
    guapiles->crearSolicitud("S004", p4, maria, "Heredia, San Pablo", "27/10/2026", error);

    p3->registrarIncidencia(carlos, "27/10/2026");

    datosPruebaCargados = true;
    cout << "Datos de prueba cargados:" << endl;
    cout << "  Centros C01 y C02, 4 clientes, 3 colaboradores, 5 bodegas y 7 paquetes." << endl;
    cout << "  PK102 entregado (D001 finalizado), PK105 en incidencia durante el despacho D002," << endl;
    cout << "  PK103 en incidencia dentro de bodega, PK104 con solicitud S004 pendiente y PK106 recibido." << endl;
}
