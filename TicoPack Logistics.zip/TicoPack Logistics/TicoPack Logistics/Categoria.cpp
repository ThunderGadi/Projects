#include "Categoria.h"

#include <iostream>

using namespace std;

const double Categoria::TARIFA_GENERAL = 1500.0;
const double Categoria::TARIFA_FRAGIL = 2000.0;
const double Categoria::TARIFA_TECNOLOGIA = 2500.0;
const double Categoria::TARIFA_DOCUMENTOS = 1000.0;

bool Categoria::esValida(int codigo) {
    return codigo >= GENERAL && codigo <= DOCUMENTOS;
}

string Categoria::nombre(int codigo) {
    switch (codigo) {
        case GENERAL: return "General";
        case FRAGIL: return "Fragil";
        case TECNOLOGIA: return "Tecnologia";
        case DOCUMENTOS: return "Documentos";
        default: return "Desconocida";
    }
}

double Categoria::tarifaPorKilogramo(int codigo) {
    switch (codigo) {
        case GENERAL: return TARIFA_GENERAL;
        case FRAGIL: return TARIFA_FRAGIL;
        case TECNOLOGIA: return TARIFA_TECNOLOGIA;
        case DOCUMENTOS: return TARIFA_DOCUMENTOS;
        default: return 0.0;
    }
}

void Categoria::mostrarOpciones() {
    for (int i = GENERAL; i <= DOCUMENTOS; i++) {
        cout << "  " << i << ". " << nombre(i) << endl;
    }
}
