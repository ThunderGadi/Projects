#ifndef LISTA_H
#define LISTA_H

template <class T>
class Nodo {
private:
    T dato;
    Nodo<T>* siguiente;

public:
    Nodo(T dato) {
        this->dato = dato;
        siguiente = nullptr;
    }

    T getDato() const {
        return dato;
    }

    Nodo<T>* getSiguiente() const {
        return siguiente;
    }

    void setSiguiente(Nodo<T>* siguiente) {
        this->siguiente = siguiente;
    }
};

template <class T>
class Lista {
private:
    Nodo<T>* primero;
    Nodo<T>* ultimo;
    int cantidad;

public:
    Lista() {
        primero = nullptr;
        ultimo = nullptr;
        cantidad = 0;
    }


    ~Lista() {
        limpiar();
    }

    void agregar(T valor) {
        Nodo<T>* nuevo = new Nodo<T>(valor);
        if (primero == nullptr) {
            primero = nuevo;
        } else {
            ultimo->setSiguiente(nuevo);
        }
        ultimo = nuevo;
        cantidad++;
    }

    Nodo<T>* getPrimero() const {
        return primero;
    }

    T get(int posicion) const {
        if (posicion < 0 || posicion >= cantidad) return T();
        Nodo<T>* actual = primero;
        for (int i = 0; i < posicion; i++) actual = actual->getSiguiente();
        return actual->getDato();
    }

    bool contiene(T valor) const {
        for (Nodo<T>* actual = primero; actual != nullptr; actual = actual->getSiguiente()) {
            if (actual->getDato() == valor) return true;
        }
        return false;
    }

    bool eliminarDato(T valor) {
        Nodo<T>* anterior = nullptr;
        Nodo<T>* actual = primero;
        while (actual != nullptr && !(actual->getDato() == valor)) {
            anterior = actual;
            actual = actual->getSiguiente();
        }
        if (actual == nullptr) return false;
        if (anterior == nullptr) {
            primero = actual->getSiguiente();
        } else {
            anterior->setSiguiente(actual->getSiguiente());
        }
        if (actual == ultimo) ultimo = anterior;
        delete actual;
        cantidad--;
        return true;
    }

    T extraerPrimero() {
        if (primero == nullptr) return T();
        Nodo<T>* borrar = primero;
        T valor = borrar->getDato();
        primero = primero->getSiguiente();
        if (primero == nullptr) ultimo = nullptr;
        delete borrar;
        cantidad--;
        return valor;
    }

    bool vacia() const {
        return primero == nullptr;
    }

    int size() const {
        return cantidad;
    }

    void limpiar() {
        while (primero != nullptr) {
            Nodo<T>* borrar = primero;
            primero = primero->getSiguiente();
            delete borrar;
        }
        ultimo = nullptr;
        cantidad = 0;
    }
};

#endif
