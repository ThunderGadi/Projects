#include "Celda.h"

Celda::Celda() : paquete(nullptr) {
}

bool Celda::estaLibre() const {
    return paquete == nullptr;
}

Paquete* Celda::getPaquete() const {
    return paquete;
}

bool Celda::asignarPaquete(Paquete* paquete) {
    if (paquete == nullptr || this->paquete != nullptr) return false;
    this->paquete = paquete;
    return true;
}

void Celda::liberar() {
    paquete = nullptr;
}
