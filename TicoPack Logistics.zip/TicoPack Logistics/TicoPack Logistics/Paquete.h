#ifndef PAQUETE_H
#define PAQUETE_H

#include <string>
#include "Lista.h"

using namespace std;

class Bodega;
class Cliente;
class Colaborador;
class CentroDistribucion;
class Despacho;
class RegistroEstado;

class Paquete {
private:
    string codigoUnico;
    string descripcion;
    double peso;
    int categoria;
    Cliente* cliente;
    CentroDistribucion* centro;
    string estadoActual;
    Bodega* bodega;
    int fila;
    int columna;
    Despacho* despacho;
    Lista<RegistroEstado*> bitacora;

    bool transicionPermitida(const string& nuevoEstado);
    bool colaboradorValido(Colaborador* colaborador);
    bool cambiarEstado(const string& nuevoEstado, Colaborador* colaborador, const string& fecha);
    void liberarUbicacion();

public:
    static const string RECIBIDO;
    static const string ALMACENADO;
    static const string EN_TRANSITO;
    static const string ENTREGADO;
    static const string INCIDENCIA;

    Paquete(string codigoUnico, string descripcion, double peso, int categoria,
        Cliente* cliente, CentroDistribucion* centro);
    ~Paquete();


    string getCodigoUnico();
    string getDescripcion();
    double getPeso();
    int getCategoria();
    string getNombreCategoria();
    Cliente* getCliente();
    CentroDistribucion* getCentro();
    string getEstadoActual();
    Bodega* getBodega();
    int getFila();
    int getColumna();
    Despacho* getDespacho();
    string getUbicacion();
    bool tieneUbicacion();
    bool tieneDespachoEnProceso();
    bool requiereAlmacenamiento();
    Lista<RegistroEstado*>& getBitacora();

    bool almacenar(Bodega* bodega, int fila, int columna, Colaborador* colaborador, const string& fecha);
    bool reubicar(Bodega* nuevaBodega, int fila, int columna);
    bool registrarIncidencia(Colaborador* colaborador, const string& fecha);
    bool resolverIncidencia(Colaborador* colaborador, const string& fecha);
    bool iniciarTransito(Despacho* despacho, Colaborador* colaborador, const string& fecha);
    bool entregar(Colaborador* colaborador, const string& fecha);

    void mostrarDatos();
    void mostrarBitacora();
};

#endif
