#include "Empresa.h"

#include <iostream>

using namespace std;

Empresa::Empresa(string idCliente, string nombre, string telefono, string correo,
    string actividadEconomica, double porcentajeDescuento)
    : Cliente(idCliente, nombre, telefono, correo) {
    this->actividadEconomica = actividadEconomica;
    this->porcentajeDescuento = descuentoValido(porcentajeDescuento) ? porcentajeDescuento : 0.0;
}

string Empresa::getActividadEconomica() {
    return actividadEconomica;
}

double Empresa::getPorcentajeDescuento() {
    return porcentajeDescuento;
}

bool Empresa::descuentoValido(double porcentaje) {
    return porcentaje >= 0.0 && porcentaje <= 100.0;
}

string Empresa::getTipo() {
    return "Empresa";
}

double Empresa::aplicarDescuento(double costoBase) {
    return costoBase - (costoBase * porcentajeDescuento / 100.0);
}

void Empresa::mostrar() {
    mostrarDatosBase();
    cout << "Actividad economica: " << actividadEconomica << endl;
    cout << "Descuento autorizado: " << porcentajeDescuento << "%" << endl;
}
