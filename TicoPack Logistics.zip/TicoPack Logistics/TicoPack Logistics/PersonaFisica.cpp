#include "PersonaFisica.h"

#include <iostream>

using namespace std;

PersonaFisica::PersonaFisica(string idCliente, string nombre, string telefono, string correo)
    : Cliente(idCliente, nombre, telefono, correo) {
}

string PersonaFisica::getTipo() {
    return "Persona fisica";
}

void PersonaFisica::mostrar() {
    mostrarDatosBase();
}
