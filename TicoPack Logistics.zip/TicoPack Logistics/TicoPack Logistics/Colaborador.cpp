#include "Colaborador.h"

#include <iostream>

using namespace std;

Colaborador::Colaborador(string idColaborador, string nombre, string fechaIngreso, string puesto) {
    this->idColaborador = idColaborador;
    this->nombre = nombre;
    this->fechaIngreso = fechaIngreso;
    this->puesto = puesto;
}

string Colaborador::getIdColaborador() {
    return idColaborador;
}

string Colaborador::getNombre() {
    return nombre;
}

string Colaborador::getFechaIngreso() {
    return fechaIngreso;
}

string Colaborador::getPuesto() {
    return puesto;
}

void Colaborador::mostrarDatos() {
    cout << "Identificacion: " << idColaborador << endl;
    cout << "Nombre completo: " << nombre << endl;
    cout << "Fecha de ingreso: " << fechaIngreso << endl;
    cout << "Puesto: " << puesto << endl;
}
