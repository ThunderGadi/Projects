#ifndef REGISTROESTADO_H
#define REGISTROESTADO_H

#include <string>

using namespace std;

class Colaborador;

class RegistroEstado{
private:
    string estadoAnterior;
    string estadoNuevo;
    string fecha;
    Colaborador* colaborador;

public:
    RegistroEstado(string estadoAnterior, string estadoNuevo, string fecha, Colaborador* colaborador);

    string getEstadoAnterior();
    string getEstadoNuevo();
    string getFecha();
    
    Colaborador* getColaborador();
    
    void mostrarDatos();
    
};

#endif 