#include "reporte.h"
#include <iostream>
#include <iomanip>
using namespace std;

void Reportes::canchaConMasReservas(const CanchaColeccion& canchas, const ReservaColeccion& reservas) {
    if (canchas.getCantidad() == 0) {
        cout << "No hay canchas registradas.\n";
        return;
    }

    int mayor = -1;
    Cancha* mejor = nullptr;

    for (int i = 0; i < canchas.getCantidad(); i++) {
        Cancha* cancha = canchas.getCancha(i);
        int cantidad = reservas.contarActivasPorCancha(cancha);

        if (cantidad > mayor) {
            mayor = cantidad;
            mejor = cancha;
        }
    }

    cout << "\n--- CANCHA CON MAS RESERVAS ACTIVAS ---\n";
    mejor->mostrar();
    cout << "Reservas activas: " << mayor << endl;

    cout << "Detalle:\n";
    reservas.mostrarPorCancha(mejor);
}

void Reportes::clienteConMasReservas(const ClienteColeccion& clientes, const ReservaColeccion& reservas) {
    if (clientes.getCantidad() == 0) {
        cout << "No hay clientes registrados.\n";
        return;
    }

    int mayor = -1;
    Cliente* mejor = nullptr;

    for (int i = 0; i < clientes.getCantidad(); i++) {
        Cliente* cliente = clientes.getCliente(i);
        int cantidad = reservas.contarActivasPorCliente(cliente);

        if (cantidad > mayor) {
            mayor = cantidad;
            mejor = cliente;
        }
    }

    cout << "\n--- CLIENTE CON MAS RESERVAS ACTIVAS ---\n";
    mejor->mostrar();
    cout << "Reservas activas: " << mayor << endl;

    cout << "Detalle:\n";
    reservas.mostrarPorCliente(mejor);
}

void Reportes::ingresoTotal(const ReservaColeccion& reservas) {
    cout << "\n--- INGRESO TOTAL DE RESERVAS ACTIVAS ---\n";
    cout << fixed << setprecision(2);
    cout << "Ingreso total: " << reservas.ingresoTotalActivo() << endl;

    cout << "\nDetalle de reservas:\n";

    bool encontro = false;

    for (int i = 0; i < reservas.getCantidad(); i++) {
        Reserva* reserva = reservas.getReserva(i);

        if (reserva->estaActiva()) {
            reserva->mostrar();
            encontro = true;
        }
    }

    if (!encontro) {
        cout << "No existen reservas activas.\n";
    }
}

void Reportes::ocupacionPorCancha(const CanchaColeccion& canchas) {
    cout << "\n--- PORCENTAJE DE OCUPACION ---\n";

    if (canchas.getCantidad() == 0) {
        cout << "No hay canchas registradas.\n";
        return;
    }

    for (int i = 0; i < canchas.getCantidad(); i++) {
        Cancha* cancha = canchas.getCancha(i);

        int ocupadas = 0;

        for (int j = 0; j < 12; j++) {
            if (cancha->estaOcupada(j)) {
                ocupadas++;
            }
        }

        double porcentaje = (ocupadas / 12.0) * 100.0;

        cout << "Cancha " << cancha->getCodigo()
             << " (" << cancha->getDeporte() << ")"
             << " -> " << fixed << setprecision(2)
             << porcentaje << "% ocupada"
             << " (" << ocupadas << "/12 franjas)\n";
    }
}

void Reportes::horasMayorYMenor(const ReservaColeccion& reservas) {
    cout << "\n--- HORAS CON MAYOR Y MENOR CANTIDAD DE RESERVAS ---\n";

    int mayor = -1;
    int menor = 100000;

    for (int i = 0; i < 12; i++) {
        int cantidad = reservas.contarActivasPorFranja(i);

        if (cantidad > mayor) {
            mayor = cantidad;
        }

        if (cantidad < menor) {
            menor = cantidad;
        }
    }

    if (mayor == 0) {
        cout << "No existen reservas activas.\n";
        return;
    }

    cout << "Mayor cantidad de reservas: " << mayor << endl;

    for (int i = 0; i < 12; i++) {
        if (reservas.contarActivasPorFranja(i) == mayor) {
            cout << "  " << 8 + i << ":00 - " << 9 + i << ":00\n";
        }
    }

    cout << "Menor cantidad de reservas: " << menor << endl;

    for (int i = 0; i < 12; i++) {
        if (reservas.contarActivasPorFranja(i) == menor) {
            cout << "  " << 8 + i << ":00 - " << 9 + i << ":00\n";
        }
    }
}