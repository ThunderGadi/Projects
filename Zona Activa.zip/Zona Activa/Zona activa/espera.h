#ifndef ESPERA_H
#define ESPERA_H

#include "Cliente.h"
#include "Cancha.h"

class Espera {
private:
    int numero;
    Cliente* cliente;
    Cancha* cancha;
    int franja;
    int estado; 

public:
    Espera();

    void configurar(int numero, Cliente* cliente, Cancha* cancha, int franja);

    int getNumero() const;
    Cliente* getCliente() const;
    Cancha* getCancha() const;
    int getFranja() const;
    int getEstado() const;

    void asignar();
    void cancelar();

    bool estaEsperando() const;
    bool mismaSolicitud(Cliente* cliente, Cancha* cancha, int franja) const;

    void mostrar() const;
};

#endif
