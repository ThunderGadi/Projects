#include "Cliente.h"
#include <iostream>
#include <cstring>

static void copiarTexto(char* destino, int capacidad, const char* origen) {
    if (destino == nullptr || capacidad <= 0) return;
    if (origen == nullptr) origen = "";
    std::strncpy(destino, origen, capacidad - 1);
    destino[capacidad - 1] = '\0';
}
using namespace std;

Cliente::Cliente() {
    identificacion = 0;
    nombre[0] = '\0';
    telefono[0] = '\0';
}

Cliente::Cliente(int identificacion, const char* nombre, const char* telefono) {
    this->identificacion = identificacion;
    copiarTexto(this->nombre, sizeof(this->nombre), nombre);
    copiarTexto(this->telefono, sizeof(this->telefono), telefono);
}

int Cliente::getIdentificacion() const {
    return identificacion;
}

const char* Cliente::getNombre() const {
    return nombre;
}

const char* Cliente::getTelefono() const {
    return telefono;
}

void Cliente::setNombre(const char* nombre) {
    copiarTexto(this->nombre, sizeof(this->nombre), nombre);
}

void Cliente::setTelefono(const char* telefono) {
    copiarTexto(this->telefono, sizeof(this->telefono), telefono);
}

void Cliente::mostrar() const {
    cout << "ID: " << identificacion
         << " | Nombre: " << nombre
         << " | Telefono: " << telefono << endl;
}
