#ifndef CANCHACOLECCION_H
#define CANCHACOLECCION_H

#include "Cancha.h"

class CanchaColeccion {
private:
    Cancha* canchas[10];
    int cantidad;

public:
    CanchaColeccion();
    ~CanchaColeccion();

    bool agregar(Cancha* cancha);
    Cancha* buscar(int codigo) const;

    void mostrarTodas() const;

    int getCantidad() const;
    Cancha* getCancha(int indice) const;
};

#endif
