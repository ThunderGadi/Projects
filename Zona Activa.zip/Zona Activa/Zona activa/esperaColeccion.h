#ifndef ESPERACOLECCION_H
#define ESPERACOLECCION_H

#include "Espera.h"

class EsperaColeccion {
private:
    Espera* esperas[10];
    int cantidad;
    int siguienteNumero;

public:
    EsperaColeccion();
    ~EsperaColeccion();

    bool registrar(Cliente* cliente, Cancha* cancha, int franja);
    Espera* buscar(int numero) const;

    bool existeSolicitud(Cliente* cliente, Cancha* cancha, int franja) const;

    void mostrarTodas() const;
    void mostrarPorCanchaYFranja(Cancha* cancha, int franja) const;

    bool cambiarEstado(int numero, int nuevoEstado);

    // Devuelve la primera persona en espera 
    Espera* primeraEnEspera(Cancha* cancha, int franja) const;

    int getCantidad() const;
    Espera* getEspera(int indice) const;
};

#endif