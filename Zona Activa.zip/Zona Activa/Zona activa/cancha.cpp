#include "Cancha.h"
#include <iostream>
#include <cstring>

static void copiarTexto(char* destino, int capacidad, const char* origen) {
    if (destino == nullptr || capacidad <= 0) return;
    if (origen == nullptr) origen = "";
    std::strncpy(destino, origen, capacidad - 1);
    destino[capacidad - 1] = '\0';
}
using namespace std;

Cancha::Cancha() {
    codigo = 0;
    deporte[0] = '\0';
    precioHora = 0;

    for (int i = 0; i < 12; i++) {
        franjas[i] = 'L';
    }
}

Cancha::Cancha(int codigo, const char* deporte, double precioHora) {
    this->codigo = codigo;
    copiarTexto(this->deporte, sizeof(this->deporte), deporte);
    this->precioHora = precioHora;

    for (int i = 0; i < 12; i++) {
        franjas[i] = 'L';
    }
}

int Cancha::getCodigo() const {
    return codigo;
}

const char* Cancha::getDeporte() const {
    return deporte;
}

double Cancha::getPrecioHora() const {
    return precioHora;
}

char Cancha::getEstadoFranja(int posicion) const {
    if (!posicionValida(posicion)) {
        return '?';
    }

    return franjas[posicion];
}

void Cancha::setPrecioHora(double precioHora) {
    if (precioHora >= 0) {
        this->precioHora = precioHora;
    }
}

bool Cancha::posicionValida(int posicion) const {
    return posicion >= 0 && posicion < 12;
}

bool Cancha::estaLibre(int posicion) const {
    return posicionValida(posicion) && franjas[posicion] == 'L';
}

bool Cancha::estaOcupada(int posicion) const {
    return posicionValida(posicion) && franjas[posicion] == 'O';
}

bool Cancha::estaEnMantenimiento(int posicion) const {
    return posicionValida(posicion) && franjas[posicion] == 'M';
}

bool Cancha::reservarFranja(int posicion) {
    if (!estaLibre(posicion)) {
        return false;
    }

    franjas[posicion] = 'O';
    return true;
}

bool Cancha::liberarFranja(int posicion) {
    if (!estaOcupada(posicion)) {
        return false;
    }

    franjas[posicion] = 'L';
    return true;
}

bool Cancha::ponerMantenimiento(int posicion) {
    if (!estaLibre(posicion)) {
        return false;
    }

    franjas[posicion] = 'M';
    return true;
}

bool Cancha::retirarMantenimiento(int posicion) {
    if (!estaEnMantenimiento(posicion)) {
        return false;
    }

    franjas[posicion] = 'L';
    return true;
}

void Cancha::mostrar() const {
    cout << "Codigo: " << codigo
         << " | Deporte: " << deporte
         << " | Precio por hora: " << precioHora << endl;
}

void Cancha::mostrarDisponibilidad() const {
    cout << "\nDisponibilidad de cancha " << codigo << endl;

    for (int i = 0; i < 12; i++) {
        int horaInicio = 8 + i;

        cout << "[" << i + 1 << "] "
             << horaInicio << ":00 - "
             << horaInicio + 1 << ":00 -> "
             << franjas[i] << endl;
    }

    cout << "L = Libre | O = Ocupada | M = Mantenimiento\n";
}
