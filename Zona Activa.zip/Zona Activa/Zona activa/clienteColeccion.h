#ifndef CLIENTECOLECCION_H
#define CLIENTECOLECCION_H

#include "Cliente.h"

class ClienteColeccion {
private:
    Cliente* clientes[100];
    int cantidad;

public:
    ClienteColeccion();
    ~ClienteColeccion();

    bool agregar(Cliente* cliente);
    Cliente* buscar(int identificacion) const;

    void mostrarTodos() const;
    void mostrarCliente(int identificacion) const;

    int getCantidad() const;
    Cliente* getCliente(int indice) const;
};

#endif
