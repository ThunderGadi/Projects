#include "EsperaColeccion.h"
#include <iostream>
using namespace std;

EsperaColeccion::EsperaColeccion() {
    cantidad = 0;
    siguienteNumero = 1;

    for (int i = 0; i < 10; i++) {
        esperas[i] = nullptr;
    }
}

EsperaColeccion::~EsperaColeccion() {
    for (int i = 0; i < cantidad; i++) {
        delete esperas[i];
    }
}

bool EsperaColeccion::registrar(Cliente* cliente, Cancha* cancha, int franja) {
    if (cliente == nullptr || cancha == nullptr) {
        return false;
    }

    if (cantidad >= 10) {
        return false;
    }

    if (franja < 0 || franja >= 12) {
        return false;
    }

    
    if (!cancha->estaOcupada(franja)) {
        return false;
    }

    //un cliente no puede aparecer dos veces esperando por la misma cancha y horario
   
    if (existeSolicitud(cliente, cancha, franja)) {
        return false;
    }

    Espera* nueva = new Espera();
    nueva->configurar(siguienteNumero, cliente, cancha, franja);

    esperas[cantidad] = nueva;
    cantidad++;
    siguienteNumero++;

    return true;
}

Espera* EsperaColeccion::buscar(int numero) const {
    for (int i = 0; i < cantidad; i++) {
        if (esperas[i]->getNumero() == numero) {
            return esperas[i];
        }
    }

    return nullptr;
}

bool EsperaColeccion::existeSolicitud(Cliente* cliente, Cancha* cancha, int franja) const {
    for (int i = 0; i < cantidad; i++) {
        if (esperas[i]->mismaSolicitud(cliente, cancha, franja)) {
            return true;
        }
    }

    return false;
}

void EsperaColeccion::mostrarTodas() const {
    if (cantidad == 0) {
        cout << "No hay personas en lista de espera.\n";
        return;
    }

    for (int i = 0; i < cantidad; i++) {
        esperas[i]->mostrar();
    }
}

void EsperaColeccion::mostrarPorCanchaYFranja(Cancha* cancha, int franja) const {
    bool encontro = false;

    for (int i = 0; i < cantidad; i++) {
        if (esperas[i]->getCancha() == cancha &&
            esperas[i]->getFranja() == franja &&
            esperas[i]->estaEsperando()) {

            esperas[i]->mostrar();
            encontro = true;
        }
    }

    if (!encontro) {
        cout << "No hay personas esperando para esa cancha y franja.\n";
    }
}

bool EsperaColeccion::cambiarEstado(int numero, int nuevoEstado)
{
    Espera* espera = buscar(numero);

    if (espera == nullptr)
    {
        return false;
    }

    if (!espera->estaEsperando())
    {
        return false;
    }

    if (nuevoEstado == 2)
    {
        espera->asignar();
    }
    else if (nuevoEstado == 3)
    {
        espera->cancelar();
    }
    else
    {
        return false;
    }

    return true;
}

Espera* EsperaColeccion::primeraEnEspera(Cancha* cancha, int franja) const {
    for (int i = 0; i < cantidad; i++) {
        if (esperas[i]->getCancha() == cancha &&
            esperas[i]->getFranja() == franja &&
            esperas[i]->estaEsperando()) {
            return esperas[i];
        }
    }

    return nullptr;
}

int EsperaColeccion::getCantidad() const {
    return cantidad;
}

Espera* EsperaColeccion::getEspera(int indice) const {
    if (indice < 0 || indice >= cantidad) {
        return nullptr;
    }

    return esperas[indice];
}
