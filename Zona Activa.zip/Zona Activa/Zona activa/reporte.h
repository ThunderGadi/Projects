#ifndef REPORTES_H
#define REPORTES_H

#include "ClienteColeccion.h"
#include "CanchaColeccion.h"
#include "ReservaColeccion.h"

class Reportes {
public:
    static void canchaConMasReservas(const CanchaColeccion& canchas, const ReservaColeccion& reservas);

    static void clienteConMasReservas(const ClienteColeccion& clientes, const ReservaColeccion& reservas);

    static void ingresoTotal(const ReservaColeccion& reservas);

    static void ocupacionPorCancha(const CanchaColeccion& canchas);

    static void horasMayorYMenor(const ReservaColeccion& reservas);
};

#endif
