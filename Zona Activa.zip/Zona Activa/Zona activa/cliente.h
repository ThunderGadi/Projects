#ifndef CLIENTE_H
#define CLIENTE_H

class Cliente {
private:
    int identificacion;
    char nombre[80];
    char telefono[20];

public:
    Cliente();
    Cliente(int identificacion, const char* nombre, const char* telefono);

    int getIdentificacion() const;
    const char* getNombre() const;
    const char* getTelefono() const;

    void setNombre(const char* nombre);
    void setTelefono(const char* telefono);

    void mostrar() const;
};

#endif
