#ifndef RESERVACOLECCION_H
#define RESERVACOLECCION_H

#include "reservas.h"

class ReservaColeccion {
private:
    Reserva* reservas[120];
    int cantidad;
    int siguienteNumero;

public:
    ReservaColeccion();
    ~ReservaColeccion();

    Reserva* crearReserva(Cliente* cliente, Cancha* cancha, int franjaInicial, int cantidadFranjas);

    bool agregar(Reserva* reserva);
    Reserva* buscar(int numero) const;

    void mostrarTodas() const;
    void mostrarPorCliente(Cliente* cliente) const;
    void mostrarPorCancha(Cancha* cancha) const;

    int contarActivasPorCliente(Cliente* cliente) const;
    int contarActivasPorCancha(Cancha* cancha) const;
    int contarActivasPorFranja(int franja) const;

    double ingresoTotalActivo() const;

    bool cancelar(int numero);

    int getCantidad() const;
    Reserva* getReserva(int indice) const;
};

#endif
