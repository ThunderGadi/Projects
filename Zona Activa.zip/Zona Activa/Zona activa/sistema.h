#ifndef SISTEMA_H
#define SISTEMA_H

#include "CanchaColeccion.h"
#include "ClienteColeccion.h"
#include "ReservaColeccion.h"
#include "EsperaColeccion.h"
#include "reporte.h"

class Sistema {
private:
    CanchaColeccion canchas;
    ClienteColeccion clientes;
    ReservaColeccion reservas;
    EsperaColeccion esperas;

    void limpiarEntrada();
    int leerEntero(const char* mensaje);
    int leerEnteroNoNegativo(const char* mensaje);
    double leerPrecio(const char* mensaje);
    int leerFranja();

    void registrarCancha();
    void modificarPrecioCancha();
    void gestionarMantenimiento();

    void registrarCliente();

    void registrarReserva();
    void cancelarReserva();

    void registrarEsperaManual();
    void cambiarEstadoEspera();

public:
    Sistema();
    ~Sistema();

    void menuPrincipal();
    void menuCanchas();
    void menuClientes();
    void menuReservas();
    void menuEspera();
    void menuReportes();
};

#endif