#include "Espera.h"
#include <iostream>
using namespace std;

Espera::Espera() {
    numero = 0;
    cliente = nullptr;
    cancha = nullptr;
    franja = 0;
    estado = 1;
}

void Espera::configurar(int numero, Cliente* cliente, Cancha* cancha, int franja) {
    this->numero = numero;
    this->cliente = cliente;
    this->cancha = cancha;
    this->franja = franja;
    this->estado = 1;
}

int Espera::getNumero() const {
    return numero;
}

Cliente* Espera::getCliente() const {
    return cliente;
}

Cancha* Espera::getCancha() const {
    return cancha;
}

int Espera::getFranja() const {
    return franja;
}

int Espera::getEstado() const {
    return estado;
}

void Espera::asignar() {
    estado = 2;
}

void Espera::cancelar() {
    estado = 3;
}

bool Espera::estaEsperando() const {
    return estado == 1;
}

bool Espera::mismaSolicitud(Cliente* cliente, Cancha* cancha, int franja) const {
    return this->cliente == cliente &&
           this->cancha == cancha &&
           this->franja == franja &&
           estaEsperando();
}

void Espera::mostrar() const {
    const char* textoEstado;

    if (estado == 1)
        textoEstado = "Esperando";
    else if (estado == 2)
        textoEstado = "Asignado";
    else
        textoEstado = "Cancelado";

    cout << "Espera #" << numero
         << " | Cliente: " << cliente->getNombre()
         << " | Cancha: " << cancha->getCodigo()
         << " | Franja: " << franja + 1
         << " | Estado: " << textoEstado
         << endl;
}
