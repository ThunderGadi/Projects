#ifndef RESERVA_H
#define RESERVA_H

#include "Cliente.h"
#include "Cancha.h"

class Reserva {
private:
    int numero;
    Cliente* cliente;
    Cancha* cancha;
    int franjaInicial;
    int cantidadFranjas;
    double monto;
    bool activa;

public:
    Reserva();

    void configurar(int numero, Cliente* cliente, Cancha* cancha, int franjaInicial, int cantidadFranjas);

    int getNumero() const;
    Cliente* getCliente() const;
    Cancha* getCancha() const;
    int getFranjaInicial() const;
    int getCantidadFranjas() const;
    double getMonto() const;
    bool estaActiva() const;

    bool afectaFranja(int posicion) const;

    void cancelar();
    void mostrar() const;
};

#endif