#include "reservas.h"
#include <iostream>
using namespace std;

Reserva::Reserva() {
    numero = 0;
    cliente = nullptr;
    cancha = nullptr;
    franjaInicial = 0;
    cantidadFranjas = 0;
    monto = 0;
    activa = false;
}

void Reserva::configurar(int numero, Cliente* cliente, Cancha* cancha, int franjaInicial, int cantidadFranjas) {
    this->numero = numero;
    this->cliente = cliente;
    this->cancha = cancha;
    this->franjaInicial = franjaInicial;
    this->cantidadFranjas = cantidadFranjas;
    this->monto = cancha->getPrecioHora() * cantidadFranjas;
    this->activa = true;
}

int Reserva::getNumero() const {
    return numero;
}

Cliente* Reserva::getCliente() const {
    return cliente;
}

Cancha* Reserva::getCancha() const {
    return cancha;
}

int Reserva::getFranjaInicial() const {
    return franjaInicial;
}

int Reserva::getCantidadFranjas() const {
    return cantidadFranjas;
}

double Reserva::getMonto() const {
    return monto;
}

bool Reserva::estaActiva() const {
    return activa;
}

bool Reserva::afectaFranja(int posicion) const {
    return posicion >= franjaInicial && posicion < franjaInicial + cantidadFranjas;
}

void Reserva::cancelar() {
    if (!activa) {
        return;
    }

    for (int i = 0; i < cantidadFranjas; i++) {
        cancha->liberarFranja(franjaInicial + i);
    }

    activa = false;
}

void Reserva::mostrar() const {
    cout << "Reserva #" << numero
         << " | Cliente: " << cliente->getNombre()
         << " | Cancha: " << cancha->getCodigo()
         << " | Inicio: " << 8 + franjaInicial << ":00"
         << " | Horas: " << cantidadFranjas
         << " | Monto: " << monto
         << " | Estado: " << (activa ? "Activa" : "Cancelada")
         << endl;
}