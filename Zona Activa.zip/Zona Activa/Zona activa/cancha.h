#ifndef CANCHA_H
#define CANCHA_H

class Cancha {
private:
    int codigo;
    char deporte[40];
    double precioHora;
    char franjas[12]; 

public:
    Cancha();
    Cancha(int codigo, const char* deporte, double precioHora);

    int getCodigo() const;
    const char* getDeporte() const;
    double getPrecioHora() const;
    char getEstadoFranja(int posicion) const;

    void setPrecioHora(double precioHora);

    bool posicionValida(int posicion) const;
    bool estaLibre(int posicion) const;
    bool estaOcupada(int posicion) const;
    bool estaEnMantenimiento(int posicion) const;

    bool reservarFranja(int posicion);
    bool liberarFranja(int posicion);
    bool ponerMantenimiento(int posicion);
    bool retirarMantenimiento(int posicion);

    void mostrar() const;
    void mostrarDisponibilidad() const;
};

#endif
