#include "CanchaColeccion.h"
#include <iostream>
using namespace std;

CanchaColeccion::CanchaColeccion() {
    cantidad = 0;

    for (int i = 0; i < 10; i++) {
        canchas[i] = nullptr;
    }
}

CanchaColeccion::~CanchaColeccion() {
    for (int i = 0; i < cantidad; i++) {
        delete canchas[i];
    }
}

bool CanchaColeccion::agregar(Cancha* cancha) {
    if (cancha == nullptr || cantidad >= 10) {
        return false;
    }

    if (buscar(cancha->getCodigo()) != nullptr) {
        return false;
    }

    canchas[cantidad] = cancha;
    cantidad++;

    return true;
}

Cancha* CanchaColeccion::buscar(int codigo) const {
    for (int i = 0; i < cantidad; i++) {
        if (canchas[i]->getCodigo() == codigo) {
            return canchas[i];
        }
    }

    return nullptr;
}

void CanchaColeccion::mostrarTodas() const {
    if (cantidad == 0) {
        cout << "No hay canchas registradas.\n";
        return;
    }

    for (int i = 0; i < cantidad; i++) {
        canchas[i]->mostrar();
    }
}

int CanchaColeccion::getCantidad() const {
    return cantidad;
}

Cancha* CanchaColeccion::getCancha(int indice) const {
    if (indice < 0 || indice >= cantidad) {
        return nullptr;
    }

    return canchas[indice];
}
