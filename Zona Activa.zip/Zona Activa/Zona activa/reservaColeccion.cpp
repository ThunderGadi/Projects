#include "reservaColeccion.h"
#include <iostream>
using namespace std;

ReservaColeccion::ReservaColeccion() {
    cantidad = 0;
    siguienteNumero = 1;

    for (int i = 0; i < 120; i++) {
        reservas[i] = nullptr;
    }
}

ReservaColeccion::~ReservaColeccion() {
    for (int i = 0; i < cantidad; i++) {
        delete reservas[i];
    }
}

bool ReservaColeccion::agregar(Reserva* reserva) {
    if (reserva == nullptr || cantidad >= 120) {
        return false;
    }

    reservas[cantidad] = reserva;
    cantidad++;

    return true;
}

Reserva* ReservaColeccion::crearReserva(Cliente* cliente, Cancha* cancha, int franjaInicial, int cantidadFranjas) {
    if (cliente == nullptr || cancha == nullptr) {
        return nullptr;
    }

    if (cantidad >= 120) {
        return nullptr;
    }

    if (franjaInicial < 0 || franjaInicial >= 12 ||
        cantidadFranjas <= 0 ||
        franjaInicial + cantidadFranjas > 12) {
        return nullptr;
    }

    for (int i = 0; i < cantidadFranjas; i++) {
        if (!cancha->estaLibre(franjaInicial + i)) {
            return nullptr;
        }
    }

    for (int i = 0; i < cantidadFranjas; i++) {
        cancha->reservarFranja(franjaInicial + i);
    }

    Reserva* nuevaReserva = new Reserva();

    nuevaReserva->configurar(
        siguienteNumero,
        cliente,
        cancha,
        franjaInicial,
        cantidadFranjas
    );

    if (!agregar(nuevaReserva)) {
        for (int i = 0; i < cantidadFranjas; i++) {
            cancha->liberarFranja(franjaInicial + i);
        }

        delete nuevaReserva;
        return nullptr;
    }

    siguienteNumero++;

    return nuevaReserva;
}

Reserva* ReservaColeccion::buscar(int numero) const {
    for (int i = 0; i < cantidad; i++) {
        if (reservas[i]->getNumero() == numero) {
            return reservas[i];
        }
    }

    return nullptr;
}

void ReservaColeccion::mostrarTodas() const {
    if (cantidad == 0) {
        cout << "No hay reservas registradas.\n";
        return;
    }

    for (int i = 0; i < cantidad; i++) {
        reservas[i]->mostrar();
    }
}

void ReservaColeccion::mostrarPorCliente(Cliente* cliente) const {
    if (cliente == nullptr) {
        return;
    }

    bool encontro = false;

    for (int i = 0; i < cantidad; i++) {
        if (reservas[i]->getCliente() == cliente) {
            reservas[i]->mostrar();
            encontro = true;
        }
    }

    if (!encontro) {
        cout << "El cliente no tiene reservas registradas.\n";
    }
}

void ReservaColeccion::mostrarPorCancha(Cancha* cancha) const {
    if (cancha == nullptr) {
        return;
    }

    bool encontro = false;

    for (int i = 0; i < cantidad; i++) {
        if (reservas[i]->getCancha() == cancha) {
            reservas[i]->mostrar();
            encontro = true;
        }
    }

    if (!encontro) {
        cout << "La cancha no tiene reservas registradas.\n";
    }
}

int ReservaColeccion::contarActivasPorCliente(Cliente* cliente) const {
    int total = 0;

    for (int i = 0; i < cantidad; i++) {
        if (reservas[i]->estaActiva() &&
            reservas[i]->getCliente() == cliente) {
            total++;
        }
    }

    return total;
}

int ReservaColeccion::contarActivasPorCancha(Cancha* cancha) const {
    int total = 0;

    for (int i = 0; i < cantidad; i++) {
        if (reservas[i]->estaActiva() &&
            reservas[i]->getCancha() == cancha) {
            total++;
        }
    }

    return total;
}

int ReservaColeccion::contarActivasPorFranja(int franja) const {
    int total = 0;

    for (int i = 0; i < cantidad; i++) {
        if (reservas[i]->estaActiva() &&
            reservas[i]->afectaFranja(franja)) {
            total++;
        }
    }

    return total;
}

double ReservaColeccion::ingresoTotalActivo() const {
    double total = 0;

    for (int i = 0; i < cantidad; i++) {
        if (reservas[i]->estaActiva()) {
            total += reservas[i]->getMonto();
        }
    }

    return total;
}

bool ReservaColeccion::cancelar(int numero) {
    Reserva* reserva = buscar(numero);

    if (reserva == nullptr || !reserva->estaActiva()) {
        return false;
    }

    reserva->cancelar();
    return true;
}

int ReservaColeccion::getCantidad() const {
    return cantidad;
}

Reserva* ReservaColeccion::getReserva(int indice) const {
    if (indice < 0 || indice >= cantidad) {
        return nullptr;
    }

    return reservas[indice];
}