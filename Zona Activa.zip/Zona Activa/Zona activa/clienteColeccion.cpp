#include "ClienteColeccion.h"
#include <iostream>
using namespace std;

ClienteColeccion::ClienteColeccion() {
    cantidad = 0;

    for (int i = 0; i < 100; i++) {
        clientes[i] = nullptr;
    }
}

ClienteColeccion::~ClienteColeccion() {
    for (int i = 0; i < cantidad; i++) {
        delete clientes[i];
    }
}

bool ClienteColeccion::agregar(Cliente* cliente) {
    if (cliente == nullptr || cantidad >= 100) {
        return false;
    }

    if (buscar(cliente->getIdentificacion()) != nullptr) {
        return false;
    }

    clientes[cantidad] = cliente;
    cantidad++;

    return true;
}

Cliente* ClienteColeccion::buscar(int identificacion) const {
    for (int i = 0; i < cantidad; i++) {
        if (clientes[i]->getIdentificacion() == identificacion) {
            return clientes[i];
        }
    }

    return nullptr;
}

void ClienteColeccion::mostrarTodos() const {
    if (cantidad == 0) {
        cout << "No hay clientes registrados.\n";
        return;
    }

    for (int i = 0; i < cantidad; i++) {
        clientes[i]->mostrar();
    }
}

void ClienteColeccion::mostrarCliente(int identificacion) const {
    Cliente* cliente = buscar(identificacion);

    if (cliente == nullptr) {
        cout << "Cliente no encontrado.\n";
        return;
    }

    cliente->mostrar();
}

int ClienteColeccion::getCantidad() const {
    return cantidad;
}

Cliente* ClienteColeccion::getCliente(int indice) const {
    if (indice < 0 || indice >= cantidad) {
        return nullptr;
    }

    return clientes[indice];
}
