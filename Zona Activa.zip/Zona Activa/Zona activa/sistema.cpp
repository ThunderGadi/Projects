#include "Sistema.h"
#include <iostream>
#include <limits>
#include <iomanip>

using namespace std;

Sistema::Sistema() {
}

Sistema::~Sistema() {
}

void Sistema::limpiarEntrada() {
    cin.clear();
    cin.ignore(numeric_limits<streamsize>::max(), '\n');
}

int Sistema::leerEntero(const char* mensaje) {
    int valor;

    while (true) {
        cout << mensaje;

        if (cin >> valor) {
            return valor;
        }

        cout << "Entrada invalida. Debe ingresar un numero.\n";
        limpiarEntrada();
    }
}

int Sistema::leerEnteroNoNegativo(const char* mensaje) {
    int valor;

    do {
        valor = leerEntero(mensaje);

        if (valor < 0) {
            cout << "El valor no puede ser negativo.\n";
        }
    } while (valor < 0);

    return valor;
}

double Sistema::leerPrecio(const char* mensaje) {
    double valor;

    while (true) {
        cout << mensaje;

        if (cin >> valor && valor >= 0) {
            return valor;
        }

        cout << "El valor debe ser mayor o igual a cero.\n";
        limpiarEntrada();
    }
}

int Sistema::leerFranja() {
    int franja;

    do {
        franja = leerEntero("Franja (1-12): ");

        if (franja < 1 || franja > 12) {
            cout << "La franja debe estar entre 1 y 12.\n";
        }
    } while (franja < 1 || franja > 12);

    return franja - 1;
}

// MENU PRINCIPAL

void Sistema::menuPrincipal() {
    int opcion;

    do {
        system("cls");
        cout << "\n\n============================================\n";
        cout << "       CENTRO DEPORTIVO ZONA ACTIVA\n";
        cout << "============================================\n";
        cout << "1. Gestion de canchas\n";
        cout << "2. Gestion de clientes\n";
        cout << "3. Gestion de reservas\n";
        cout << "4. Gestion de listado de espera\n";
        cout << "5. Reportes y estadisticas\n";
        cout << "6. Salir\n";
        cout << "============================================\n";
        opcion = leerEntero("Seleccione una opcion: ");
        switch (opcion) {
        case 1:
            menuCanchas();
            break;
        case 2:
            menuClientes();
            break;
        case 3:
            menuReservas();
            break;
        case 4:
            menuEspera();
            break;
        case 5:
            menuReportes();
            break;
        case 6:
            cout << "Gracias por utilizar Zona Activa.\n";
            break;
        default:
            cout << "Opcion invalida.\n";
        }
    } while (opcion != 6);
}

// GESTION DE CANCHAS

void Sistema::registrarCancha() {
    int codigo = leerEnteroNoNegativo("Codigo de la cancha: ");

    if (canchas.buscar(codigo) != nullptr) {
        cout << "Ya existe una cancha con ese codigo.\n";
        return;
    }

    char deporte[40];

    cout << "Tipo de deporte: ";
    cin >> ws;
    cin.getline(deporte, 40);

    double precio = leerPrecio("Precio de alquiler por hora: ");

    Cancha* nueva = new Cancha(codigo, deporte, precio);

    if (canchas.agregar(nueva)) {
        cout << "Cancha registrada correctamente.\n";
    } else {
        cout << "No se pudo registrar la cancha.\n";
        delete nueva;
    }
}

void Sistema::modificarPrecioCancha() {
    int codigo = leerEnteroNoNegativo("Codigo de la cancha: ");
    Cancha* cancha = canchas.buscar(codigo);

    if (cancha == nullptr) {
        cout << "Cancha no encontrada.\n";
        return;
    }

    double nuevoPrecio = leerPrecio("Nuevo precio por hora: ");
    cancha->setPrecioHora(nuevoPrecio);

    cout << "Precio actualizado correctamente.\n";
}

void Sistema::gestionarMantenimiento() {
    int codigo = leerEnteroNoNegativo("Codigo de la cancha: ");
    Cancha* cancha = canchas.buscar(codigo);

    if (cancha == nullptr) {
        cout << "Cancha no encontrada.\n";
        return;
    }

    cout << "\n1. Colocar mantenimiento\n";
    cout << "2. Retirar mantenimiento\n";

    int opcion = leerEntero("Seleccione: ");

    if (opcion != 1 && opcion != 2) {
        cout << "Opcion invalida.\n";
        return;
    }

    int franja = leerFranja();
    bool resultado = false;

    if (opcion == 1) {
        resultado = cancha->ponerMantenimiento(franja);

        if (!resultado) {
            cout << "No se puede colocar mantenimiento. "
                << "La franja puede estar ocupada o no estar libre.\n";
        }
    } else {
        resultado = cancha->retirarMantenimiento(franja);

        if (!resultado) {
            cout << "La franja no esta en mantenimiento.\n";
        }
    }

    if (resultado) {
        cout << "Operacion realizada correctamente.\n";
    }
}

void Sistema::menuCanchas() {
    int opcion;

    do {
        system("cls");
        cout << "\n=================================\n";
        cout << "       GESTION DE CANCHAS\n";
        cout << "=================================\n";
        cout << "1. Registrar cancha\n";
        cout << "2. Mostrar todas\n";
        cout << "3. Buscar cancha\n";
        cout << "4. Modificar precio\n";
        cout << "5. Mostrar disponibilidad\n";
        cout << "6. Mantenimiento\n";
        cout << "0. Volver\n";

        opcion = leerEntero("Seleccione una opcion: ");

        switch (opcion) {
        case 1:
            registrarCancha();
            system("pause");
            break;
        case 2:
            canchas.mostrarTodas();
            system("pause");
            break;
        case 3: {
            int codigo = leerEnteroNoNegativo("Codigo: ");
            Cancha* cancha = canchas.buscar(codigo);

            if (cancha != nullptr) cancha->mostrar();
            else cout << "Cancha no encontrada.\n";
            system("pause");
            break;
        }
        case 4:
            modificarPrecioCancha();
            system("pause");
            break;
        case 5: {
            int codigo = leerEnteroNoNegativo("Codigo: ");
            Cancha* cancha = canchas.buscar(codigo);

            if (cancha != nullptr) cancha->mostrarDisponibilidad();
            else cout << "Cancha no encontrada.\n";
            system("pause");
            break;
        }
        case 6:
            gestionarMantenimiento();
            system("pause");
            break;
        case 0:
            break;
        default:
            cout << "Opcion invalida.\n";
            system("pause");
        }
    } while (opcion != 0);
}

// GESTION DE CLIENTES

void Sistema::registrarCliente() {
    int identificacion = leerEnteroNoNegativo("Identificacion: ");

    if (clientes.buscar(identificacion) != nullptr) {
        cout << "Ya existe un cliente con esa identificacion.\n";
        return;
    }

    char nombre[80];
    char telefono[20];

    cout << "Nombre completo: ";
    cin >> ws;
    cin.getline(nombre, 80);

    cout << "Telefono: ";
    cin.getline(telefono, 20);

    Cliente* nuevo = new Cliente(identificacion, nombre, telefono);

    if (clientes.agregar(nuevo)) {
        cout << "Cliente registrado correctamente.\n";
    } else {
        cout << "No se pudo registrar el cliente.\n";
        delete nuevo;
    }
}

void Sistema::menuClientes() {
    int opcion;

    do {
        system("cls");
        cout << "\n=================================\n";
        cout << "       GESTION DE CLIENTES\n";
        cout << "=================================\n";
        cout << "1. Registrar cliente\n";
        cout << "2. Mostrar clientes\n";
        cout << "3. Buscar cliente\n";
        cout << "4. Mostrar reservas de un cliente\n";
        cout << "0. Volver\n";

        opcion = leerEntero("Seleccione una opcion: ");

        switch (opcion) {
        case 1:
            registrarCliente();
            system("pause");
            break;
        case 2:
            clientes.mostrarTodos();
            system("pause");
            break;
        case 3: {
            int id = leerEnteroNoNegativo("Identificacion: ");
            clientes.mostrarCliente(id);
            system("pause");
            break;
        }
        case 4: {
            int id = leerEnteroNoNegativo("Identificacion: ");
            Cliente* cliente = clientes.buscar(id);

            if (cliente == nullptr) cout << "Cliente no encontrado.\n";
            else reservas.mostrarPorCliente(cliente);
            system("pause");
            break;
        }
        case 0:
            break;
        default:
            cout << "Opcion invalida.\n";
            system("pause");
        }
    } while (opcion != 0);
}

// GESTION DE RESERVAS

void Sistema::registrarReserva() {
    int id = leerEnteroNoNegativo("Identificacion del cliente: ");
    Cliente* cliente = clientes.buscar(id);

    if (cliente == nullptr) {
        cout << "El cliente no esta registrado.\n";
        return;
    }

    int codigo = leerEnteroNoNegativo("Codigo de cancha: ");
    Cancha* cancha = canchas.buscar(codigo);

    if (cancha == nullptr) {
        cout << "La cancha no existe.\n";
        return;
    }

    int franjaInicial = leerFranja();
    int cantidadFranjas = leerEntero("Cantidad de horas consecutivas: ");

    if (cantidadFranjas <= 0 || franjaInicial + cantidadFranjas > 12) {
        cout << "La cantidad de franjas no es valida.\n";
        return;
    }

    bool hayOcupada = false;
    bool hayMantenimiento = false;

    for (int i = 0; i < cantidadFranjas; i++) {
        int posicion = franjaInicial + i;

        if (cancha->estaOcupada(posicion)) hayOcupada = true;
        if (cancha->estaEnMantenimiento(posicion)) hayMantenimiento = true;
    }

    if (hayOcupada) {
        cout << "Una o mas franjas estan ocupadas.\n";
        cout << "Puede registrar al cliente en lista de espera para una franja ocupada.\n";

        int respuesta = leerEntero("Desea registrar espera para la primera franja ocupada? (1=Si, 0=No): ");

        if (respuesta == 1) {
            for (int i = 0; i < cantidadFranjas; i++) {
                int posicion = franjaInicial + i;

                if (cancha->estaOcupada(posicion)) {
                    if (esperas.registrar(cliente, cancha, posicion)) {
                        cout << "Cliente agregado a lista de espera para la franja "
                            << posicion + 1 << ".\n";
                    } else {
                        cout << "No se pudo registrar la espera. Puede que ya exista una solicitud o la lista este llena.\n";
                    }
                    break;
                }
            }
        } else if (respuesta != 0) {
            cout << "Opcion invalida.\n";
        }

        return;
    }

    if (hayMantenimiento) {
        cout << "Una o mas franjas estan en mantenimiento. No se puede realizar la reserva.\n";
        cout << "Tampoco se permite lista de espera para mantenimiento.\n";
        return;
    }

    Reserva* reserva = reservas.crearReserva(cliente, cancha, franjaInicial, cantidadFranjas);

    if (reserva != nullptr) {
        cout << "Reserva creada correctamente.\n";
        reserva->mostrar();
    } else {
        cout << "No se pudo crear la reserva.\n";
    }
}

void Sistema::cancelarReserva() {
    int numero = leerEnteroNoNegativo("Numero de reserva: ");
    Reserva* reserva = reservas.buscar(numero);

    if (reserva == nullptr) {
        cout << "Reserva no encontrada.\n";
        return;
    }

    if (!reserva->estaActiva()) {
        cout << "La reserva ya esta cancelada.\n";
        return;
    }

    Cancha* cancha = reserva->getCancha();
    int inicio = reserva->getFranjaInicial();
    int cantidad = reserva->getCantidadFranjas();

    reserva->cancelar();

    cout << "Reserva cancelada correctamente.\n";

    for (int i = 0; i < cantidad; i++) {
        int franja = inicio + i;
        Espera* espera = esperas.primeraEnEspera(cancha, franja);

        if (espera != nullptr) {
            cout << "\nATENCION: existe una persona esperando:\n";
            espera->mostrar();
            cout << "La franja " << franja + 1 << " ahora esta libre.\n";
        }
    }
}

void Sistema::menuReservas() {
    int opcion;

    do {
        system("cls");
        cout << "\n=================================\n";
        cout << "       GESTION DE RESERVAS\n";
        cout << "=================================\n";
        cout << "1. Registrar reserva\n";
        cout << "2. Mostrar todas\n";
        cout << "3. Buscar reserva\n";
        cout << "4. Mostrar reservas de una cancha\n";
        cout << "5. Cancelar reserva\n";
        cout << "0. Volver\n";

        opcion = leerEntero("Seleccione una opcion: ");

        switch (opcion) {
        case 1:
            registrarReserva();
            system("pause");
            break;
        case 2:
            reservas.mostrarTodas();
            system("pause");
            break;
        case 3: {
            int numero = leerEnteroNoNegativo("Numero de reserva: ");
            Reserva* reserva = reservas.buscar(numero);

            if (reserva != nullptr) reserva->mostrar();
            else cout << "Reserva no encontrada.\n";
            system("pause");
            break;
        }
        case 4: {
            int codigo = leerEnteroNoNegativo("Codigo de cancha: ");
            Cancha* cancha = canchas.buscar(codigo);

            if (cancha != nullptr) reservas.mostrarPorCancha(cancha);
            else cout << "Cancha no encontrada.\n";
            system("pause");
            break;
        }
        case 5:
            cancelarReserva();
            system("pause");
            break;
        case 0:
            break;
        default:
            cout << "Opcion invalida.\n";
            system("pause");
        }
    } while (opcion != 0);
}

// LISTA DE ESPERA

void Sistema::registrarEsperaManual() {
    int id = leerEnteroNoNegativo("Identificacion del cliente: ");
    Cliente* cliente = clientes.buscar(id);

    if (cliente == nullptr) {
        cout << "Cliente no encontrado.\n";
        return;
    }

    int codigo = leerEnteroNoNegativo("Codigo de cancha: ");
    Cancha* cancha = canchas.buscar(codigo);

    if (cancha == nullptr) {
        cout << "Cancha no encontrada.\n";
        return;
    }

    int franja = leerFranja();

    if (cancha->estaEnMantenimiento(franja)) {
        cout << "No se puede registrar espera: la franja esta en mantenimiento.\n";
        return;
    }

    if (!cancha->estaOcupada(franja)) {
        cout << "La franja no esta ocupada. La lista de espera solo aplica cuando esta ocupada.\n";
        return;
    }

    if (esperas.registrar(cliente, cancha, franja)) {
        cout << "Cliente registrado en lista de espera.\n";
    } else {
        cout << "No se pudo registrar. Puede existir una solicitud igual o estar llena la lista.\n";
    }
}

void Sistema::cambiarEstadoEspera() {
    int numero = leerEnteroNoNegativo("Numero de espera: ");
    Espera* espera = esperas.buscar(numero);

    if (espera == nullptr) {
        cout << "Registro no encontrado.\n";
        return;
    }

    cout << "1. Asignado\n";
    cout << "2. Cancelado\n";

    int opcion = leerEntero("Nuevo estado: ");

    if (opcion == 1) {
        if (esperas.cambiarEstado(numero, 2)) cout << "Estado cambiado a asignado.\n";
        else cout << "No se pudo cambiar el estado.\n";
    } else if (opcion == 2) {
        if (esperas.cambiarEstado(numero, 3)) cout << "Estado cambiado a cancelado.\n";
        else cout << "No se pudo cambiar el estado.\n";
    } else {
        cout << "Opcion invalida.\n";
    }
}

void Sistema::menuEspera() {
    int opcion;

    do {
        system("cls");
        cout << "\n=================================\n";
        cout << "       LISTADO DE ESPERA\n";
        cout << "=================================\n";
        cout << "1. Registrar cliente en espera\n";
        cout << "2. Mostrar listado\n";
        cout << "3. Mostrar por cancha y franja\n";
        cout << "4. Cambiar estado\n";
        cout << "0. Volver\n";

        opcion = leerEntero("Seleccione una opcion: ");

        switch (opcion) {
        case 1:
            registrarEsperaManual();
            system("pause");
            break;
        case 2:
            esperas.mostrarTodas();
            system("pause");
            break;
        case 3: {
            int codigo = leerEnteroNoNegativo("Codigo de cancha: ");
            Cancha* cancha = canchas.buscar(codigo);

            if (cancha == nullptr) {
                cout << "Cancha no encontrada.\n";
                system("pause");
                break;
            }

            int franja = leerFranja();
            esperas.mostrarPorCanchaYFranja(cancha, franja);
            system("pause");
            break;
        }
        case 4:
            cambiarEstadoEspera();
            system("pause");
            break;
        case 0:
        system("pause");
            break;
        default:
            cout << "Opcion invalida.\n";
            system("pause");
        }
    } while (opcion != 0);
}

// REPORTES

void Sistema::menuReportes() {
    int opcion;

    do {
        system("cls");
        cout << "\n=================================\n";
        cout << "       REPORTES Y ESTADISTICAS\n";
        cout << "=================================\n";
        cout << "1. Cancha con mayor cantidad de reservas activas\n";
        cout << "2. Cliente con mayor cantidad de reservas activas\n";
        cout << "3. Ingreso total de reservas activas\n";
        cout << "4. Porcentaje de ocupacion de cada cancha\n";
        cout << "5. Horas con mayor y menor cantidad de reservas\n";
        cout << "0. Volver\n";

        opcion = leerEntero("Seleccione una opcion: ");

        switch (opcion) {
        case 1:
            Reportes::canchaConMasReservas(canchas, reservas);
            system("pause");
            break;
        case 2:
            Reportes::clienteConMasReservas(clientes, reservas);
            system("pause");
            break;
        case 3:
            Reportes::ingresoTotal(reservas);
            system("pause");
            break;
        case 4:
            Reportes::ocupacionPorCancha(canchas);
            system("pause");
            break;
        case 5:
            Reportes::horasMayorYMenor(reservas);
            system("pause");
            break;
        case 0:
            system("pause");
            break;
        default:
            cout << "Opcion invalida.\n";
            system("pause");
        }
    } while (opcion != 0);

}